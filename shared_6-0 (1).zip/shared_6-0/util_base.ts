// util_base.ts 
