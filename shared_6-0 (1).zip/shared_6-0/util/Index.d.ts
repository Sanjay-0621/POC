/// <reference types="C:\Procify_Global_nodemodules/node_modules/@sapui5/ts-types" />
/// <reference types="jquery" />
/// <reference types="jquery" />
type ValueBag = {
    't_name': string;
    't_value': string;
}[];
export declare class Index {
    private bFromForgetPassword;
    private _i8n;
    private sActionFrom;
    private fromNoUserForgetPassword;
    init(): Promise<void>;
    private _lockScreen;
    private _initializei8n;
    setUILabel(): Promise<void>;
    onClickLoginRegistration(): Promise<void>;
    onClickSignUpNext(): Promise<void>;
    private _doRegister;
    private _fnValidatePassword;
    onValidateOTP(): Promise<void>;
    onClickConfirmPassword(): Promise<void>;
    private _confirmPassword;
    private onNavAddUser;
    private onNavChangeUser;
    private onClickUsersList;
    onClickLogin(): void;
    onLoginOffline(): Promise<void>;
    onLoginOnline(): Promise<void>;
    _fnShowErrorMsgInDevModel(oControl: JQuery<HTMLElement>, errorText: string): void;
    _fnShowErrorMsg(oControl: JQuery<HTMLElement>, errorText: string): void;
    private _fnShowSuccessMsg;
    private _fnShowErrorPage;
    private _showUserConfirmPage;
    onInputKeyPress(event: any): void;
    onClickAccept(): Promise<void>;
    private _attachProgressCallbacks;
    onClickReject(): void;
    private _fnShowOnlinePage;
    onNavForgetPasswordOnline(): void;
    onNavBack(): void;
    onNavForgetPasswordOffline(): void;
    onClosePasswordPolicy(): void;
    onClickFpNext(): Promise<void>;
    validatePhone(mNum: string): boolean;
    getValueBagFromDOM(formid: string): ValueBag;
    fnResendOtp(): Promise<void>;
    onNavSignUp(): void;
    private _removeMsg;
    private _removeInvalidClass;
    private showPage;
    private _clear_form_elements;
    private _enable_disable_button;
    private hidePage;
    onNavSignIn(): void;
    acceptFunction(): void;
    private _hideSplashScreen;
    private _disableApplicationCSS;
    private _showAppHideContent;
    private _showContentHideApp;
    private lock;
    private _loadComponent;
    private showPasswordPolicy;
    validatePasswordPolicy(): Promise<void>;
    bioMetricValidation(): Promise<void>;
    private enableFingerPrint;
    private _isSAPSessionValid;
    private _seam4Component;
    private _loadSeam4Component;
}
export {};
//# sourceMappingURL=Index.d.ts.map