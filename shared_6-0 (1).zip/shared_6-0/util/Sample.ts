declare let clientGlobalObj: any;
class Sample {

    private fwSampleObj: any;
    // private initPromise: Promise < any > ;
    private acceptRejectPromise = window["DelayedPromise"];
    private initPromise: DelayedPromise;
    private bFromForgetPassword: boolean = false;
    private _i8n;
    private sActionFrom: string = '';
    private oUIConfig;
    private fromNoUserForgetPassword: boolean;

    // constructor(){
    //     clientGlobalObj.fwSample = window["fwSample"];//.getInstance();
    // }

    public async initUi(): Promise<void> {
        // this.initPromise = clientGlobalObj.fwSample.initPromise;
        this.initPromise = clientGlobalObj.fwSample.initPromise
        //clientGlobalObj.fwSample.downloadCommonAndExternal();
        await clientGlobalObj.fwSample.init();
        this.setUILabel();
        let endPointId = null;
        let activeUser = null;
        let userList = JSON.parse(localStorage.getItem(clientGlobalObj.landscape + "_USER_LIST"))
        if (userList) {
            for (let user of userList) {
                if (user["is_active"] == true)
                    activeUser = user;
            }
        }
        endPointId = activeUser ? activeUser.endPointId : null
        //Determine which page to load
        if (location.href.indexOf("forget_password") > 1) {
            this.bFromForgetPassword = true;
            //let loggedInUser=sessionStorage.getItem("LOGIN_USER_ID");
            let loggedInUserEPI = endPointId
            var oUserInfo = loggedInUserEPI ? JSON.parse(sessionStorage.getItem(loggedInUserEPI + "_USER_INFO")) : null;
            if (oUserInfo) {
                this.onNavForgetPasswordOffline();
            } else {
                this.onNavForgetPasswordOnline();
            }
        } else if (location.href.indexOf("signup") > 1) {
            this.onNavSignUp();
        }
        else if ( !location.href.match("addSession") && JSON.parse(localStorage.getItem(endPointId + "_RESOLVED_USER_INFO"))?.regInfo.IS_REGISTRATION_COMPLETED) {
            this._fnShowOnlinePage();
        }
        else {
            this._removeMsg();
            this._removeInvalidClass();
            //@ts-ignore
            if (typeof cordova == 'object') {
                $(".app").css({ display: "block" })
            }
            this.showPage("page_login");
        }

        //Floating Label events
        var formInputs = $('input[type="text"],input[type="password"],input[type="number"],input[type="textfield"],input[type="tel"]');
        formInputs.focus(function () {
            $(this).parent().children('p.formLabel').addClass('formTop');
        });
        formInputs.focusout(function () {
            //@ts-ignore
            let value: string = $(this).val();
            if ($.trim(value).length == 0) {
                $(this).parent().children('p.formLabel').removeClass('formTop');
            }
        });
        $('p.formLabel').click(function () {
            $(this).parent().children('input.inputstyle').focus();
        });

        /**********Place your init code here*******/
        // var sOrientation = this.getOrientation();
        // var sFormFactor = this.getFormFactor();



        /**********End of your Init Code************/

        //Register Globel Ajax Calls for showing indicators
        // (function () {
        //     var vAjaxCounter = 0;
        //     $(document).bind("ajaxSend", function () {
        //         vAjaxCounter++;
        //         $(".loading").removeClass("hidden");
        //         console.log("Ajax Send " + vAjaxCounter);
        //     }).bind("ajaxComplete", function () {
        //         vAjaxCounter--;
        //         console.log("Ajax fineshed " + vAjaxCounter);
        //         if (vAjaxCounter <= 0) {
        //             $(".loading").addClass("hidden");
        //         }
        //     });
        // })();

        //oUtil.hideSplashScreen();
        //Disabling device back button press
        document.addEventListener("backbutton", function (e) {
            e.preventDefault();
        }, false);
        await this.initPromise.promise;
        $(".fixedBox").css({ display: "block" });
        //Click of eye icons in password
        $('.field-icon').click(function () {
            var parent = $(this).parent()[0];
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
                parent.children[3].setAttribute('style', "display:none")
                parent.children[4].setAttribute('style', "display:block")
            } else {
                input.attr("type", "password");
                parent.children[3].setAttribute('style', "display:block")
                parent.children[4].setAttribute('style', "display:none")

            }
        });

    }


    public setUILabel() {
        var sDefaultLang = 'en';
        /****************************************/
        var sBrowserLang = navigator.language;
        this._i8n = (<any>window).i8n_Klarion_registraion[sBrowserLang] ? (<any>window).i8n_Klarion_registraion[sBrowserLang] : (<any>window).i8n_Klarion_registraion[sDefaultLang];
        let _i8n = this._i8n;

        //window["oOfflineLoginInfo"]=JSON.parse(sessionStorage.getItem('offline_page_info')) || {};

        document.getElementById('link_signin').innerHTML = _i8n["already_have_acc"];
        document.getElementById('link_back').innerHTML = _i8n["back"];
        document.getElementById('reg_next').innerHTML = _i8n["next"];
        document.getElementById('reg_mobile').innerHTML = _i8n["mobile_number"];
        document.getElementById('reg_bp').innerHTML = _i8n["bp_id"];
        document.getElementById('reg_emp').innerHTML = _i8n["employee_id"];

        document.getElementById('reg_emp_fp').innerHTML = _i8n["employee_id"];
        document.getElementById('otp_input').innerHTML = _i8n["enter_otp"];
        document.getElementById('otp_next').innerHTML = _i8n["next"];
        document.getElementById('otp_not_recieved').innerHTML = _i8n["did_not_recieve_otp"];
        document.getElementById('page_otp_link_resend_otp').innerHTML = _i8n["resend_otp"];

        document.getElementById('link_fp').innerHTML = _i8n["forget_password"];
        document.getElementById('link_signup').innerHTML = _i8n["sign_up"];
        document.getElementById('login_span').innerHTML = _i8n["login"];
        document.getElementById('login_emp_id').innerHTML = _i8n["employee_id"];
        document.getElementById('login_pass').innerHTML = _i8n["password"];
        document.getElementById('login_or').innerHTML = "----------" + _i8n["or"] + "----------";
        document.getElementById('login_social_media').innerHTML = _i8n["sign_in_with_sm"];
        document.getElementById('login_have_account').innerHTML = _i8n["have_account"];
        document.getElementById('login_keep_signedin').innerHTML = _i8n["keep_signed_in"];

        document.getElementById('conf_password').innerHTML = _i8n["password"];
        document.getElementById('conf_confirm_password').innerHTML = _i8n["confirm_password"];
        document.getElementById('conf_register').innerHTML = _i8n["register"];

        document.getElementById('online_login_password').innerHTML = _i8n["password"];
        document.getElementById('page_login_online_link_fp').innerHTML = _i8n["forget_password"];
        document.getElementById('online_login').innerHTML = _i8n["login"];
        document.getElementById('link_change_user').innerHTML = _i8n["change_user"];
        document.getElementById('link_add_session').innerHTML = _i8n["add_user"];

        document.getElementById('conf_user_firstname').innerHTML = _i8n["first_name"];
        document.getElementById('conf_user_lastname').innerHTML = _i8n["last_name"];
        document.getElementById('conf_user_mobile').innerHTML = _i8n["mobile_number"];
        document.getElementById('conf_user_email').innerHTML = _i8n["email_address"];
        document.getElementById('conf_user_role').innerHTML = _i8n["role"];
        document.getElementById('conf_user_accept').innerHTML = _i8n["accept"];
        document.getElementById('conf_user_reject').innerHTML = _i8n["reject"];

        document.getElementById('setup_info').innerHTML = _i8n["in_progress"];

        document.getElementById('link_retry').innerHTML = _i8n["retry"];
        document.getElementById('error_oops').innerHTML = _i8n["oops"];
        document.getElementById('error_went_wrong').innerHTML = _i8n["something_went_wrong"];
        document.getElementById('error_check_internet').innerHTML = _i8n["check_internet"];
        document.getElementById('error_check_storage').innerHTML = _i8n["check_storage"];
        document.getElementById('error_check_phone').innerHTML = _i8n["check_permission"];
        document.getElementById('error_contact_admin').innerHTML = _i8n["contact_admin"];

        document.getElementById('link_switch_user_navback').innerHTML = _i8n["back"];
        document.getElementById('online_select_user').innerHTML = _i8n["select_user"];

        /*****************************************************/
        document.getElementById('termsheader').innerHTML = _i8n["terms"];
        document.getElementById('update_date').innerHTML = _i8n["lastupdate"];
        document.getElementById('p1').innerHTML = _i8n["p1"];
        document.getElementById('p2').innerHTML = _i8n["p2"];
        document.getElementById('b1').innerHTML = _i8n["b1"];
        document.getElementById('purchases').innerHTML = _i8n["purchases"];
        document.getElementById('p3').innerHTML = _i8n["p3"];
        document.getElementById('subscription').innerHTML = _i8n["subscription"];
        document.getElementById('p4').innerHTML = _i8n["p4"];
        document.getElementById('content').innerHTML = _i8n["content"];
        document.getElementById('p5').innerHTML = _i8n["p5"];
        document.getElementById('changes').innerHTML = _i8n["changes"];
        document.getElementById('p6').innerHTML = _i8n["p6"];
        document.getElementById('contactus').innerHTML = _i8n["contactus"];
        document.getElementById('p7').innerHTML = _i8n["p7"];
        document.getElementById('accept').innerHTML = _i8n["acceptagreement"];



        /**********Modify this UI config for what to show and what not*******/
        let oUIConfig = {
            "showSocialMedia": true,
            "showSignInCheckBox": false,
            "showGooglePlus": false,
            "showLinkedIn": true,
            "showTwitter": true,
            "showHeader": true,
            "showSignUp": true,
            "showEye": true,
            "showChangeUser": true,
            "showAddUser": true,
            "showPoweredBy": true,
            "showTermsAndCondition": true,
            "showPasswordPolicy": true,
            "showForgetPassword": true,
            "welcomeNoteProperty": "r_first_name" //Mention any property from user info of of local storage (may change)
        }
        /****************************************/
        //@ts-ignore
        this.oUIConfig = oUIConfig;
        !oUIConfig.showSocialMedia ? $("#registerSocialMedia").css({
            "display": "none"
        }) : null;
        !oUIConfig.showSignInCheckBox ? $("#sign_in_checkbox").css({
            "display": "none"
        }) : null;
        !oUIConfig.showGooglePlus ? $("#btn_gplus").css({
            "display": "none"
        }) : null;
        !oUIConfig.showLinkedIn ? $("#btn_linkedin").css({
            "display": "none"
        }) : null;
        !oUIConfig.showTwitter ? $("#btn_twitter").css({
            "display": "none"
        }) : null;
        !oUIConfig.showHeader ? $(".fixedHeader").css({
            "display": "none"
        }) : null;
        !oUIConfig.showSignUp ? $("#sign_up_box").css({
            "display": "none"
        }) : null;
        !oUIConfig.showPoweredBy ? $("#box_poweredby").css({
            "display": "none"
        }) : null;
        !oUIConfig.showForgetPassword ? $("#div_link").css({
            "display": "none"
        }) : null;
        !oUIConfig.showForgetPassword && !oUIConfig.showSignInCheckBox ? $("#div_fp_signcheck").css({
            "display": "none"
        }) : null;
        !oUIConfig.showEye ? ($(".field-icon").css({
            "display": "none"
        }), $('input[type="password"]').removeClass('twoSideIcon'), $('input[type="password"]').addClass('oneSideIcon')) : null;
        !oUIConfig.showTermsAndCondition ? ($('#terms').addClass('hidden'), $('#confirm').removeClass('hidden'), $('#confirm').addClass('expended')) : null;
        !oUIConfig.showPasswordPolicy ? $("#div_pp").css({
            "display": "none"
        }) : null;
        if (!oUIConfig.showChangeUser && !oUIConfig.showAddUser) {
            $("#page_user_info").css({
                "display": "none"
            });
        } else if (!oUIConfig.showChangeUser) {
            $("#link_change_user").css({
                "display": "none"
            });
            $("#page_user_info_separator").css({
                "display": "none"
            });
        } else if (!oUIConfig.showAddUser) {
            $("#link_add_session").css({
                "display": "none"
            });
            $("#page_user_info_separator").css({
                "display": "none"
            });
        }
    }


    /**
     * on Click of login
     */
    public async onClickLoginRegistration() {
        //await this.initPromise.promise;
        $(".loading").removeClass("hidden");
        let _i8n = this._i8n;
        this._enable_disable_button(true);
        this.sActionFrom = "page_login";
        var oUserValueControl = $("#page_login_inp_mob_user");
        var oPasswordControl = $("#page_login_inp_mob_password");
        var sUserId = oUserValueControl.val();
        var sPassword = oPasswordControl.val();
        if (!sUserId) {
            this._fnShowErrorMsg(oUserValueControl, _i8n["enter_mobile_no"]);
            $(".loading").addClass("hidden");
            return;
        }
        if (!sPassword) {
            this._fnShowErrorMsg(oPasswordControl, _i8n["enter_password"]);
            $(".loading").addClass("hidden");
            return;
        }

        //Validates password on click of login
        this._fnValidatePassword(sPassword, oPasswordControl).then(() => {
            //var headerBag = {workspace : "MASSETIC"};
            let oDeviceRegInfo = {
                "p_end_point": sessionStorage.getItem("endPointId"),
                "r_action": "resolve_user",
                "is_sign_up": false,
                "properties": [{
                    t_name: "page_register_inp_mob",
                    t_value: sUserId
                },
                {
                    t_name: "is_sign_up",
                    t_value: "false"
                },
                {
                    t_name: "APP_ID",
                    t_value: "browser"
                },
                ]
            };
            // if (JSON.parse(sessionStorage.getItem("DEVICE_INFO_SEND")).t_landscape_type == 'DEV') {
            //     localStorage.setItem("oDeviceRegInfo", JSON.stringify(oDeviceRegInfo));
            //     this.developerRegistration();

            // }
            // else {
                this._doRegister(oDeviceRegInfo, oUserValueControl, sPassword, false);
            //}
        })

    }

    /**
     * on click of next in signup page
     */
    public async onClickSignUpNext() {
        //await this.initPromise;
        this._enable_disable_button(true);
        this.sActionFrom = "page_register";
        var validationControl = $("#page_register_inp_mob");
        var iMobNumber = validationControl.val();
        var iValidMobileNumber;
        if (validationControl.val()) {
            var iMobNumber = validationControl.val();
            //@ts-ignore
            iValidMobileNumber = this.validatePhone(iMobNumber);
        }
        if (iValidMobileNumber) {
            var aValueBag = this.getValueBagFromDOM("page_register");
            //bFromForgetPassword?i[0].t_name="page_register_inp_mob":null;
            aValueBag.push({
                t_name: "APP_ID",
                t_value: "browser" //JSON.parse(KloLocalStorage.CONFIG_VAL).APP_ID
            });
            var oDeviceRegInfo = {
                "p_end_point": sessionStorage.getItem("endPointId"),
                "r_action": "resolve_user",
                "is_sign_up": true,
                "properties": aValueBag
            };
            this.fromNoUserForgetPassword = true;
            this._doRegister(oDeviceRegInfo, validationControl, null, true, null);
        } else {
            this._fnShowErrorMsg(validationControl, this._i8n["user_id"]);
        }
    };

    private _doRegister(oDeviceRegInfo: object, validationControl: JQuery<HTMLElement>, sPassword?: any, isNoUserForgotPwd?: boolean, headerBag?: any) {
        clientGlobalObj.fwSample.performRegisterCall(oDeviceRegInfo, sPassword, isNoUserForgotPwd, headerBag).then(() => {
            let oUserInfo = new clientGlobalObj.userInfo()
            if (oUserInfo.s_status === "OTP") {
                this.showPage("page_otp");
                this._fnShowSuccessMsg(this._i8n["successfull_otp"]);
            } else if (oUserInfo.s_status === "APPROVED") {
                if (this.sActionFrom == 'page_register') {
                    this.showPage("page_confirm_password");
                } else {
                    this._showUserConfirmPage();
                }
            } else if (oUserInfo.s_status === "WAIT") {

            } else {
                this._fnShowErrorPage();
            }
        }).catch((sErrorMsg) => {
            try {
                var oErrorMsg = JSON.parse(sErrorMsg);
                if (oErrorMsg.code == 15) {
                    this._fnShowErrorMsg(validationControl, this._i8n[oErrorMsg.code] + oErrorMsg.message);
                } else {
                    this._fnShowErrorMsg(validationControl, this._i8n[oErrorMsg.code]);
                }
            } catch (e) {
                this._fnShowErrorMsg(validationControl, sErrorMsg);
            }
        })
    }

    private _fnValidatePassword(sPassword: any, oPasswordControl: JQuery<HTMLElement>) {
        //let oThis = this;
        //let oValidatePwd = (<any>window).validatePwd.getInstance();
        var _this = this;
        return new Promise((resolve, reject) => {
            clientGlobalObj.userInfo.validate(sPassword).then(() => {
                resolve(null)
            }).catch(function () {
                reject();
                _this._fnShowErrorMsg(oPasswordControl, "Invalid Password");
            })
        })
    }

    public onValidateOTP() {
        var oUserValueControl = $("#page_otp_inp_otp");
        let oUserInfo = new clientGlobalObj.userInfo.userinfo();
        var sOptEnterted = oUserValueControl.val();
        if (!sOptEnterted) {
            this._fnShowErrorMsg(oUserValueControl, this._i8n["enter_otp"]);
            return;
        }

        //validates otp on click of next in otp page
        oUserInfo.validateOTPP(sOptEnterted).then(() => {
            if (this.sActionFrom === "page_login") {
                this._showUserConfirmPage();
            } else if (this.sActionFrom === "page_register") {
                this.showPage("page_confirm_password");
            }
        }).catch((sErrorMsg) => {
            this._fnShowErrorMsg(oUserValueControl, this._i8n[JSON.parse(sErrorMsg.responseText).code]);
        })
    };

    public onClickConfirmPassword() {
        this._enable_disable_button(true);
        var oPasswordControl = $("#page_confirm_password_inp_pswd");
        var oCnfPasswordControl = $("#page_confirm_password_inp_cnfpswd");
        var sPassword = oPasswordControl.val();
        var sPasswordConf = oCnfPasswordControl.val();
        if (!sPassword) {
            this._fnShowErrorMsg(oPasswordControl, this._i8n["enter_password"]);
            return;
        }
        if (!sPasswordConf) {
            this._fnShowErrorMsg(oCnfPasswordControl, this._i8n["confirm_password"]);
            return;
        }

        if (sPassword !== sPasswordConf) {
            this._fnShowErrorMsg(oCnfPasswordControl, this._i8n["password_not_matching"]);
            return;
        }
        this._confirmPassword(sPassword, oPasswordControl)
    }
    private _confirmPassword(sPassword, oPasswordControl) {
        let oUserInfo = new clientGlobalObj.userInfo()
        this._fnValidatePassword(sPassword, oPasswordControl).then(async () => {
            var oUserInfo = new clientGlobalObj.userInfo()
            oUserInfo.sendUserLoginCredentialToServerP(sPassword, this.bFromForgetPassword).then(async () => {
                clientGlobalObj.userInfo.login(oUserInfo.p_login_id, sPassword, oUserInfo.realmId).then(() => {
                    if (this.bFromForgetPassword == false) {
                        this._showUserConfirmPage();
                    } else {
                        //let loggedInUser=sessionStorage.getItem("LOGIN_USER_ID");
                        let loggedInUserEPI = ((clientGlobalObj.userInfo && clientGlobalObj.userInfo.getEndpointId()) || null)
                        if (loggedInUserEPI && /*localStorage.getItem(loggedInUserEPI+"_IS_ROT_SETUP_COMPLETED")=='TRUE' */ !clientGlobalObj.userInfo.getRegInfoInUserInfo("IS_ROT_SETUP_COMPLETED")) {
                            clientGlobalObj.kloReg.navigateToMainApp();
                        } else {
                            this._fnShowOnlinePage();
                        }
                    }
                }).catch((sErrorMsg) => {
                    this._fnShowErrorMsg(oPasswordControl, sErrorMsg);
                })
            })
        }).catch(() => {

        })
    }

    public developerRegistration() {
        let appDiv = document.getElementsByClassName('app')[0];
        appDiv.append(this.getDevHTMLModel());

    }

    public async onClickOfDeveloperLogin() {
        let devId = $('#page_login_inp_dev_id');
        let devPassword = $('#page_login_inp_dev_password');
        let workSpace = $('#page_login_inp_ws_id');

        if (!(devId.val())) {
            this._fnShowErrorMsgInDevModel(devId, "Enter Developer Id");
            return;
        }
        if (!(devPassword.val())) {
            this._fnShowErrorMsgInDevModel(devPassword, "Enter Developer Password");
            return;
        }
        if (!(workSpace.val())) {
            this._fnShowErrorMsgInDevModel(workSpace, "Enter Workspace Name");
            return;
        }
        clientGlobalObj.userInfo.login(devId.val(), devPassword.val(), "cloud_app").then(() => {
            let appDiv = document.getElementsByClassName("app")[0];
            appDiv.removeChild(appDiv.lastChild);
            let oUserValueControl = $("#page_login_inp_mob_user");
            let oPasswordControl = $("#page_login_inp_mob_password");
            let oDeviceRegInfo = JSON.parse(localStorage.getItem("oDeviceRegInfo"))
            localStorage.removeItem("oDeviceRegInfo");
            let workspace: any = workSpace.val();
            let headerBag = { "workspace": workspace.toUpperCase() };
            $(".loading").removeClass("hidden");
            this._doRegister(oDeviceRegInfo, oUserValueControl, oPasswordControl.val(), null, headerBag);

        }).catch((e) => {
            this._fnShowErrorMsgInDevModel(devPassword, "Invalid Developer Id Or Password");
        })
    }


    public onClickOfDevModelCheckBox() {
        let oUserValueControl = $("#page_login_inp_mob_user");
        let oPasswordControl = $("#page_login_inp_mob_password");
        let devIdInput = document.getElementById('page_login_inp_dev_id');
        let devPasswordInput = document.getElementById('page_login_inp_dev_password');
        let isChecked = $('#user_same_checkbox').is(":checked");
        if (isChecked) {
            devIdInput["value"] = oUserValueControl.val();
            devPasswordInput["value"] = oPasswordControl.val();
        }
        else {
            devIdInput["value"] = '';
            devPasswordInput["value"] = '';
        }
    }



    /**
     * on click of add user
     */
    private onNavAddUser() {
        this.showPage("page_login")
        clientGlobalObj.userInfo.markUserInActiveAndRemoveSessionStorage();
    };

    /**
     * on click of change user
     */
    private onNavChangeUser = function () {
        $('.collection-item').remove();
        var userList = JSON.parse(localStorage.getItem(clientGlobalObj.landscape + "_USER_LIST"));
        var aRegUsers = [];
        userList.forEach(user => {
            aRegUsers.push(user.user)
        })
        if (aRegUsers.length > 0) {
            aRegUsers.forEach(function (item) {
                $('#users_list').append('<a href="#!" class="collection-item">' + item + '</a>');
            });
        }
        this.showPage('page_switch_user');
    };

    /**
     * on click of item in users list
     */
    private onClickUsersList = function (event) {
        var userid = event.target.innerHTML;
        clientGlobalObj.userInfo.changeUser(userid)
        let endPointId = clientGlobalObj.userInfo.getActiveUser().endPointId + "_";
        sessionStorage.clear();
        sessionStorage.setItem('offline_page_info', this.getOfflineLoginInfo(endPointId));
        location.href = this.getActualHrefLocation() + '#'
        location.reload();
        //this._fnShowOnlinePage();
    };
    /**
 * on Click of login
 */
    public onClickLogin() {
        this._enable_disable_button(true);
        //let loggedInUser=sessionStorage.getItem("LOGIN_USER_ID");
        let loggedInUserEPI = ((clientGlobalObj.userInfo && clientGlobalObj.userInfo.getEndpointId()) || null)
        // var isUpdateAvailable=loggedInUserEPI && localStorage.getItem(loggedInUserEPI+"_UPDATE_AVAILABLE")=='TRUE'?true:false;
        var isUpdateAvailable = clientGlobalObj.userInfo.getRegInfoInUserInfo('UPDATE_AVAILABLE')
        if (loggedInUserEPI && /*localStorage.getItem(loggedInUserEPI+"_START_RECOVERY")=='TRUE' */ clientGlobalObj.userInfo.getRegInfoInUserInfo('START_RECOVERY')) {
            this.onLoginOnline();
        }
        else if (clientGlobalObj.userInfo.getRegInfoInUserInfo('IS_REGISTRATION_COMPLETED') && clientGlobalObj.userInfo.getRegInfoInUserInfo('IS_ROT_SETUP_COMPLETED') && sessionStorage.getItem('offline_page_info') && !isUpdateAvailable) {
            this.onLoginOffline();
        } else {
            this.onLoginOnline();
        }
    }
    /**
     * on  login offline
     */
    public onLoginOffline() {
        var sActualHrefLoaction = null;
        if (localStorage.getItem('CONFIG_VAL')) {
            sActualHrefLoaction = location.pathname;
        }
        else {
            sActualHrefLoaction = location.href;
        }
        var oPassword = $("#page_login_offline_password").val();
        let userInfo = clientGlobalObj.userInfo;
        let oOfflineLoginInfo = JSON.parse(sessionStorage.getItem('offline_page_info')) || {};
        if (clientGlobalObj.CONFIG_VAL && oPassword == "recover") {
            document.addEventListener("deviceready", function () {
                //var loggedInUser=sessionStorage.getItem("LOGIN_USER_ID");
                var loggedInUserEPI = ((clientGlobalObj.userInfo && clientGlobalObj.userInfo.getEndpointId()) || null)
                //var startRecoveryValue = localStorage.getItem(loggedInUserEPI+"_START_RECOVERY");
                var startRecoveryValue = clientGlobalObj.userInfo.getRegInfoInUserInfo('START_RECOVERY');
                if (startRecoveryValue === undefined || startRecoveryValue === null) {
                    localStorage.setItem(window["landscape"] + "_FILES_DOWNLOADED", JSON.stringify([]));
                    localStorage.setItem(window["landscape"] + "APPS", JSON.stringify([]));
                    //localStorage.setItem(loggedInUserEPI+"_START_RECOVERY",'TRUE');
                    clientGlobalObj.userInfo.updateRegInfoInUserInfo('START_RECOVERY');
                    alert("Start Recovery Process ! Restart the app!");
                    (<any>window).navigator.app.exitApp();
                }
            }, true)

        }
        else if (oOfflineLoginInfo.offline_login_expired === 'TRUE') {
            userInfo.login(oOfflineLoginInfo.offline_page_username, oPassword, oOfflineLoginInfo.offline_relam, function () {
                var sEncriptkey = userInfo.encryptPassword(oPassword);
                const url = sActualHrefLoaction + "?#/verified/" + sEncriptkey;
                location.hash = url;
                //@ts-ignore
                location.reload(true);
            }, function (oError) {
                this._fnShowErrorMsg($("#page_login_offline_password"), this._i8n["unable_to_login"]);
            });
        } else {
            if (userInfo.isValidPassword(oPassword, oOfflineLoginInfo.offline_page_password)) {
                var sEncriptkey = userInfo.encryptPassword(oPassword);
                 //@ts-ignore
                // if (typeof window.cordova == 'object') {
                //     const url = sActualHrefLoaction + "?#/verified/" + sEncriptkey;
                //     location.hash = url;
                //     //@ts-ignore
                //     location.reload(true);
                // } else {
                    if (clientGlobalObj.isClientCordova()) {
                        sessionStorage.setItem('IS_LOGIN_DONE', 'TRUE');
                        clientGlobalObj.userInfo.updateRegInfoInUserInfo('SHOW_LOCK_SCREEN', true);
                    }
                    var elements = document.querySelectorAll('link[rel=stylesheet]');
                    elements.forEach(function (element) {
                        if (element.id == 'mainStyle')
                            element["disabled"] = true;
                    });
                    $(".app").css({ display: "none" });
                    $(".mainIndexContent").css({ display: "block" });
                    ;
                    //}
            } else {
                this._fnShowErrorMsg($("#page_login_offline_password"), this._i8n["invalid_password"])
            }
        }
    };

    /**
     * on  login online
     */
    public onLoginOnline() {
        var oPasswordControl = $("#page_login_offline_password");
        var sPassword = oPasswordControl.val();
        if (!sPassword) {
            this._fnShowErrorMsg(oPasswordControl, this._i8n["enter_password"]);
            return;
        }
        //clientGlobalObj.kloReg.setLoginSession();
        this._fnValidatePassword(sPassword, oPasswordControl).then(async () => {
            //let loggedInUser=sessionStorage.getItem("LOGIN_USER_ID");
            let loggedInUserEPI = ((clientGlobalObj.userInfo && clientGlobalObj.userInfo.getEndpointId()) || null)
            //var isUpdateAvailable=loggedInUserEPI && localStorage.getItem(loggedInUserEPI+"_UPDATE_AVAILABLE")=='TRUE'?true:false;
            var isUpdateAvailable = clientGlobalObj.userInfo.updateRegInfoInUserInfo('UPDATE_AVAILABLE');
            var isRecovery = loggedInUserEPI && localStorage.getItem(loggedInUserEPI + "_START_RECOVERY") == 'TRUE' ? true : false;
            if (isRecovery) {
                clientGlobalObj.rotManager.startRecoveryProcess().then(() => {

                }).catch(() => {
                    this._fnShowErrorPage();
                })
                this._attachProgressCallbacks();
                this.acceptRejectPromise.resolve();
            }
            else if (isUpdateAvailable) {
                clientGlobalObj.rotManager.checkUpgrade().then(() => {

                }).catch(() => {
                    this._fnShowErrorPage();
                })
                this._attachProgressCallbacks();
                this.acceptRejectPromise.resolve();
            }
            else if (clientGlobalObj.userInfo.getRegInfoInUserInfo('IS_REGISTRATION_COMPLETED')) {
                this._attachProgressCallbacks();
                clientGlobalObj.fwSample.acceptRejectResolve();
                try {
                    await clientGlobalObj.fwSample.actionsPostRegisterCall();

                }
                catch (erro) {
                    this._fnShowErrorPage();
                    //this.showRetryPage(erro);
                }
            } else {
                this._showUserConfirmPage();
                this.fromNoUserForgetPassword = true;
            }
        }).catch(() => {

        })

    }
    /**
     * 
     * show error message in dev model
     */
    public _fnShowErrorMsgInDevModel(oControl: JQuery<HTMLElement>, errorText: string) {
        var oJQueryElement = null;
        var oJQueryElement = arguments[0];
        var sText = arguments[1];
        this._enable_disable_button(false);
        this._removeInvalidClass();
        this._removeMsg();
        if (oJQueryElement) {
            oJQueryElement.addClass("invalid");
            oJQueryElement.focus();
        }
        if (sText) {
            $(".devModel").children("form").before('<div class="error_msg"><span><i class="fas fa-exclamation-circle messageIcon"></i>' + sText + '</span></div>');
        }
    }

    /**
     * Shows Error message
     */
    public _fnShowErrorMsg(oControl: JQuery<HTMLElement>, errorText: string) {
        var oJQueryElement = null;
        var sText = null;
        this._enable_disable_button(false);
        if (arguments.length == 1) {
            sText = arguments[0];
        } else if (arguments.length == 2) {
            var oJQueryElement = arguments[0];
            var sText = arguments[1];
        }
        sText = typeof sText != "string" ? "Unexpected Exception" : sText;
        this._removeInvalidClass();
        this._removeMsg();
        if (oJQueryElement) {
            oJQueryElement.addClass("invalid");
            oJQueryElement.focus();
        }
        if (sText) {
            $(".expanded").children("form").before('<div class="error_msg"><span><i class="fas fa-exclamation-circle messageIcon"></i>' + sText + '</span></div>');
        }
    }
    /**
     * Shows success message
     */
    private _fnShowSuccessMsg(sText) {
        this._enable_disable_button(false);
        this._removeInvalidClass();
        this._removeMsg();
        if (sText) {
            $(".expanded").children("form").before('<div class="success_msg"><span><i class="fas fa-check-circle messageIcon"></i>' + sText + '</span></div>');
        }
    }
    /**
     * Shows error page
     */
    private _fnShowErrorPage() {
        this.showPage("page_error");
        $('.content').addClass("error_page");
    }
    /**
     * Shows user onfirm page
     */
    private _showUserConfirmPage() {
        let oUserInfo = new clientGlobalObj.userInfo()
        this.showPage("page_confirm_user");
        $("#page_confirm_user_inp_firstname").val(oUserInfo.r_first_name);
        $("#page_confirm_user_inp_lastname").val(oUserInfo.r_last_name);
        $("#page_confirm_user_inp_mobileno").val(oUserInfo.r_mobile_no);
        $("#page_confirm_user_inp_email").val(oUserInfo.r_email);
        $("#page_confirm_user_inp_role").val(oUserInfo.t_role_desc);
        $(".content").addClass("expand_confirm_user");
    }
    /**
 * on click enter when input is focused will invoke button click
 * * @return {string} form factor
 */
    public onInputKeyPress(event): void {
        if (event.keyCode === 13) {
            if (event.currentTarget.id == "page_login_offline_password") {
                event.preventDefault();
                document.getElementById("page_login_online_btn_login").click();
            } else if (event.currentTarget.id == "page_confirm_password_inp_pswd" || event.currentTarget.id == "page_confirm_password_inp_cnfpswd") {
                event.preventDefault();
                document.getElementById("page_confirm_password_btn_ok").click();
            } else if (event.currentTarget.id == "page_login_inp_mob_user" || event.currentTarget.id == "page_login_inp_mob_password") {
                event.preventDefault();
                document.getElementById("btn_login").click();
            } else if (event.currentTarget.id == "page_register_inp_mob" || event.currentTarget.id == "page_register_entity_id" || event.currentTarget.id == "page_register_user_id") {
                event.preventDefault();
                document.getElementById("btn_next_reg_mob").click();
            } else if (event.currentTarget.id == "page_otp_inp_otp") {
                event.preventDefault();
                document.getElementById("page_otp_btn_otp").click();
            }

        }
    }
    /**
     * on Click of Accept button
     */
    public onClickAccept() {
        this._enable_disable_button(true);
        //this.acceptRejectPromise.resolve();
        if (this.fromNoUserForgetPassword) {
            clientGlobalObj.kloReg.postRegistrationCall()
        }
        //clientGlobalObj.kloReg.markDeviceRegistrationApproved();
        clientGlobalObj.userInfo.updateRegInfoInUserInfo('IS_REGISTRATION_COMPLETED',true)
        this._attachProgressCallbacks();
    };
    /**
     * Progress indicator callback
     */
    private _attachProgressCallbacks() {
        if (!$('#page_progress').hasClass('expanded')) {
            var progress_indicator = new (<any>window).ProgressBar.Circle('#progress_bar', {
                color: '#2196F3',
                strokeWidth: 2.1,
                svgStyle: {
                    width: '160px',
                    height: '160px'
                }
            });
            $(".content").addClass("expand_progress");
            this.showPage("page_progress");
            setInterval(() => {
                var statusPercentage = clientGlobalObj.rotManager.getProgessStatus();
                progress_indicator.animate(statusPercentage / 100);
                progress_indicator.setText(Math.round(statusPercentage) + "%");
            }, 1000)
        }
    }

    /**
     * on Click of Reject button
     */
    public onClickReject() {
        this._enable_disable_button(true);
        clientGlobalObj.kloReg.cancelDeivceRegistration();
    };
    /**
     * Shows login page online
     */
    private async _fnShowOnlinePage() {
        // await this.initPromise;
        await this.initPromise.promise;
        var oUserInfo = new clientGlobalObj.userInfo();
        $("#page_login_online_userinfo span").html(this._i8n["welcome_note"] + " " + oUserInfo[this.oUIConfig.welcomeNoteProperty] + ",");
        this.showPage("page_login_online");
    }

    /**
     * on Click of forget Password
     */

    public onNavForgetPasswordOnline() {
        this.bFromForgetPassword = true;
        let loggedInUser = sessionStorage.getItem("LOGIN_USER_ID");
        let loggedInUserEPI = ((clientGlobalObj.userInfo && clientGlobalObj.userInfo.getEndpointId()) || null)
        this.showPage("page_forgot_password");
        if (loggedInUserEPI && /*localStorage.getItem( loggedInUserEPI+"_IS_REGISTRATION_COMPLETED") == 'TRUE'*/ clientGlobalObj.userInfo.getRegInfoInUserInfo("IS_REGISTRATION_COMPLETED")) {
            //@ts-ignore
            $("#page_fp_inp_mob")[0].setAttribute("readonly", true);
            //@ts-ignore
            $("#page_fp_inp_mob")[0].value = loggedInUser;
            //@ts-ignore
            let sId = $("#page_fp_inp_mob")[0].parentNode.getElementsByTagName('p')[0].id;
            $('#' + sId).addClass('formTop');
        }
        $("#link_signin_fp").show();
        $("#link_back_fp").hide();
    };

    /**
     * on Click of Back in page registration through mobile number
     */
    public onNavBack() {
        this._fnShowOnlinePage();
    };

    /**
     * on Click of forget password in offline login
     */

    public onNavBeforeForgetPasswordOffline() {
        //@ts-ignore
        if (typeof cordova == 'object') {
            var sActualHrefLoaction = location.pathname;
            const url = sActualHrefLoaction + "?#/forget_password";
            location.hash = url;
            //@ts-ignore
            location.reload(true)
        }
        else {
            this.onNavForgetPasswordOffline();
        }
    }


    public onNavForgetPasswordOffline() {
        this.bFromForgetPassword = true;
        let loggedInUser = sessionStorage.getItem("LOGIN_USER_ID");
        let loggedInUserEPI = ((clientGlobalObj.userInfo && clientGlobalObj.userInfo.getEndpointId()) || null)
        this.showPage("page_forgot_password");
        if (loggedInUserEPI && /*localStorage.getItem( loggedInUserEPI+"_IS_REGISTRATION_COMPLETED") == 'TRUE' */ clientGlobalObj.userInfo.getRegInfoInUserInfo("IS_REGISTRATION_COMPLETED")) {
            //@ts-ignore
            $("#page_fp_inp_mob")[0].setAttribute("readonly", true);
            //@ts-ignore
            $("#page_fp_inp_mob")[0].value = loggedInUser;
            //@ts-ignore
            var sId = $("#page_fp_inp_mob")[0].parentNode.getElementsByTagName('p')[0].id;
            $('#' + sId).addClass('formTop');
        }
        $("#link_signin_fp").hide();
        $("#link_back_fp").show();
    }
    /**
     * on click of next in forget password page
     */
    public async onClickFpNext() {
        //await this.initPromise;
        this._enable_disable_button(true);
        var validationControl = $("#page_fp_inp_mob");
        if (validationControl.val()) {
            //_fnAfterMobileValidation(validationControl,"form_forgot_password"); // after validation of user id.
            this.sActionFrom = "page_register";
            //let loggedInUser=sessionStorage.getItem("LOGIN_USER_ID");
            let loggedInUserEPI = ((clientGlobalObj.userInfo && clientGlobalObj.userInfo.getEndpointId()) || null)
            if (!loggedInUserEPI) {
                let oDeviceRegInfo = {
                    "p_end_point": sessionStorage.getItem("endPointId"),
                    "r_action": "resolve_user",
                    "is_sign_up": false,
                    "properties": [{
                        t_name: "page_register_inp_mob",
                        t_value: validationControl.val()
                    },
                    {
                        t_name: "is_sign_up",
                        t_value: "false"
                    },
                    {
                        t_name: "APP_ID",
                        t_value: "browser"
                    }
                    ]
                };
                clientGlobalObj.fwSample.performRegisterCall(oDeviceRegInfo, null, true).then(() => {
                    this.showPage("page_otp");
                    this.fnResendOtp();
                })
            } else {
                this.showPage("page_otp");
                this.fnResendOtp();
            }
        } else {
            this._fnShowErrorMsg(validationControl, this._i8n["user_id"]);
        }
    }
    public validatePhone(mNum: string): boolean {
        var mNumber = mNum.toString();
        if ((mNumber.match(/^(?:\+\d+[- ])?\d{10}$/) && !(mNumber.match(/0{9,}/)))) {
            return true;
        }
        return false;
    };

    /**
      * Build value bag from DOM form elements
      * @param {string} formid ID of form element
      * @return {object} it will take all the form elements and with its id,creates an
      *         object and holdes corresponding value
      **/

    public getValueBagFromDOM(formid: string): any {
        let arrayValueBag: string[] = [];

        //expected tags to be found within form-> finds also in deep dom structure
        $("#" + formid).find("select,input,textarea,button,optgroup,fieldset,label,output").each(function (index: number, oItem: any) {
            let valuebag: any = {};
            let key = oItem.id;
            valuebag["t_name"] = key;
            valuebag["t_value"] = $("#" + key).val();
            arrayValueBag.push(valuebag);
        });
        return arrayValueBag;
    };
    /**
   * on Click of resend OTP
   */
    public fnResendOtp() {
        this._enable_disable_button(true);
        var otpControl = $("#page_otp_inp_otp");

        let oUserInfo = new clientGlobalObj.userInfo();

        oUserInfo.resendOTPP().then(() => {
            this._fnShowSuccessMsg(this._i8n["successfull_otp"]);
        }).catch(function (sErrorMsg) {
            this._fnShowErrorMsg(otpControl, this._i8n[JSON.parse(sErrorMsg).code]);
        })
    }
    /**
    * on Click of Sign Up
    */
    public onNavSignUp() {
        this.bFromForgetPassword = false;
        this.showPage("page_register");
    };
    private _removeMsg(): void {
        $(".error_msg").remove();
        $(".success_msg").remove();
    }
    private _removeInvalidClass(): void {
        $(".invalid").removeClass('invalid');
    }
    private showPage(id: string): void {
        var sSelectedDomId = $(".expanded").attr('id');
        id != "page_confirm_user" ? this._clear_form_elements(id) : null;
        this._enable_disable_button(false);
        this.hidePage(sSelectedDomId);
        var pageid = "#" + id;
        this._removeInvalidClass();
        this._removeMsg();
        $(pageid).removeClass("hidden");
        $(pageid).addClass("expanded");
    }
    private _clear_form_elements(id: string): void {
        jQuery("#" + id).find(':input').each(function (evt: any) {
            switch (evt.type) {
                case 'password':
                case 'text':
                case 'textarea':
                case 'file':
                case 'select-one':
                case 'select-multiple':
                case 'date':
                case 'number':
                case 'tel':
                case 'email':
                    jQuery(evt).val('');
                    evt.getAttribute("readonly") ? evt.setAttribute("readonly", false) : null;
                    if (evt.parentNode.getElementsByTagName('p')[0]) {
                        var sId = evt.parentNode.getElementsByTagName('p')[0].id;
                        $('#' + sId).removeClass('formTop');
                    }
                    break;
                case 'checkbox':
                case 'radio':
                    evt.checked = false;
                    break;
            }
        });
    }
    private _enable_disable_button(bDisable: boolean): void {
        var sSelectedDomId = $(".expanded").attr('id');
        /*jQuery("#" + sSelectedDomId).find(':button').each(function(evt: any) {
            evt.disabled = bDisable;
        }) */
        var a = jQuery("#" + sSelectedDomId).find(':button');
        a.prop("disabled", bDisable);
    }
    private hidePage(id: string): void {
        var pageid = "#" + id;
        $(pageid).addClass("hidden");
        $(pageid).removeClass("expanded");
    }

    /**
     * on Click of Sign In in page registration through mobile number
     */
    public onNavSignIn() {
        this.showPage("page_login");
    };



    public acceptFunction() {
        $('#terms').addClass('hidden');
        $('#confirm').removeClass('hidden');
        $('#confirm').addClass('expended');  //will add the class
    }

    public getDevHTMLModel() {
        let htmlString = `<div id="myModal" class="modal">
        <div class="modal-content devModel">
            <form>
                <div class="form-item">
                    
                    <input type="textfield" placeholder="Devloper ID" class="inputstyle oneSideIcon" autocomplete="nope" maxlength="10" id="page_login_inp_dev_id">
                    <i class="fas fa-user inputFirstIcon"></i>
                </div>
                <div class="form-item">
                    
                    <input type="password" placeholder="Password" class="inputstyle twoSideIcon" id="page_login_inp_dev_password" autocomplete="new-password" spellcheck="false">
                    <span class="fas fa-lock inputFirstIcon"></span>
                    <span toggle="#page_login_inp_dev_password" class="fas fa-eye-slash field-icon"></span>
                    <span toggle="#page_login_inp_dev_password" class="fas fa-eye field-icon" style="display:none"></span>
                </div>
                <div class="form-item">
                    <input type="textfield" placeholder="Workspace Name" class="inputstyle oneSideIcon" autocomplete="nope" maxlength="30" id="page_login_inp_ws_id">
                    <i class="fa fa-folder-open inputFirstIcon"></i>
		        </div>
            </form>
                <div class="checkBoxDiv" id="div_fp_signcheck">
                    <div id="dev_model_checkbox" style="float: left;">
                        <input type="checkbox" id="user_same_checkbox" onclick="sample.onClickOfDevModelCheckBox()" />
                        <span id="devId">Use same user</span>
                    </div>
                </div>

                <div class="center_block margin_top_10">
                    <button id="btn_login" onclick="sample.onClickOfDeveloperLogin()"  class="noselect ripple"><span id="login_span" class="text">Submit</span></button>
                </div>
            
        </div>
    </div>`

        let div = document.createElement('div');
        div.innerHTML = htmlString.trim();
        return div.firstChild;

    }

    // ===================================   Registration&Login ===========================




    public afterRegistration(nextState, endPointId) {
        if (nextState == "REGISTRATION_IN_PROGRESS") {
            let sOfflineLoginInfo = this.getOfflineLoginInfo(endPointId);
            sessionStorage.setItem('offline_page_info', sOfflineLoginInfo);//additional for browser
            this.addStyleSheet();
            this._showAppHideContent();
        } else if (nextState == "ALL_DONE") {
            var elements = document.querySelectorAll('link[rel=stylesheet]');
            let sOfflineLoginInfo = this.getOfflineLoginInfo(endPointId);
            sessionStorage.setItem('offline_page_info', sOfflineLoginInfo);
            elements.forEach(function (element) {
                if (element.id == 'mainStyle')
                    element["disabled"] = true;
            });
            //localStorage.setItem(endPointId + 'SHOW_LOCK_SCREEN', 'TRUE');
            clientGlobalObj.userInfo.updateRegInfoInUserInfo('SHOW_LOCK_SCREEN', true);
            sessionStorage.setItem('IS_LOGIN_DONE', 'TRUE');//additional for mobile
            this._hideAppShowContent();
            this.loadAppJS();
            this._hideSplashScreen();//additional for mobile
        } else if (nextState == "LOGIN_REQUIRED") {
            if (clientGlobalObj.isClientCordova())
                this._lockScreenCordova();
            else {
                let sOfflineLoginInfo = this.getOfflineLoginInfo(endPointId);
                this.lockScreenBrowser(sOfflineLoginInfo);
            }
        }
    }
    public async startRegistration() {
        let nextState = clientGlobalObj.fwSample.getNextState();
        if (nextState == "FRESH_REGISTRATION") {
            //device / browser Registration start
            //this.addStyleSheet();
            await clientGlobalObj.deviceReadyPromise;
            this._showAppHideContent();
            return;
        }
        let endPointId = clientGlobalObj.userInfo.getActiveUser().endPointId + "_";
        this._setLoginSessions(endPointId);
        await clientGlobalObj.deviceReadyPromise.promise;
        this.afterRegistration(nextState, endPointId);
    }


   

    public _hideSplashScreen() { navigator["splashscreen"] && navigator["splashscreen"].hide() }

    public _showSplashScreen() { navigator["splashscreen"] && navigator["splashscreen"].show(); }

    public _lockScreenCordova(){
        var endPointId = clientGlobalObj.userInfo.getActiveUser().endPointId + "_";
        var sOfflineLoginInfo = this.getOfflineLoginInfo(endPointId);
        clientGlobalObj.userInfo.updateRegInfoInUserInfo('SHOW_LOCK_SCREEN', true);
        sessionStorage.setItem('offline_page_info', sOfflineLoginInfo);
        this._showAppHideContent();
        this.loadAppJS();
    }
   


    public lockScreenBrowser(sOfflineLoginInfo) {
        sessionStorage.setItem('IS_LOGIN_DONE', 'FALSE');
        var location_href = location.href;
        this.loadAppJS();
        if (location_href.match('/verified')) {
            // _hideAppShowContent();  
            // sessionStorage.setItem('IS_LOGIN_DONE', 'TRUE');
            // loadAppJS();
            // //location.href = location.hash.split("?#/verified/")[0];
            // if(location.hash.substr(1,location.hash.length).split("?#/verified/")[0].split('#').length == 1)
            //     location.href = location.hash.substr(1,location.hash.length).split("?#/verified/")[0] + '#';
            // else
            //     location.href = location.hash.substr(1,location.hash.length).split("?#/verified/")[0]
        }
        else if (location_href.match('#forget_password')) {
            this.addStyleSheet();
            this._showAppHideContent();
            sessionStorage.removeItem('IS_LOGIN_DONE');
        }
        else if (location_href.match('/ImpersonateUser')) {
            var aUrlSplit = location_href.split('/');
            var aUserName = aUrlSplit[(aUrlSplit.length - 1)];
            var sLocationForRedirect = this.getActualHrefLocation() + "?user='" + aUserName + "'";
            if (location_href.match('/ChangeUser')) {
                // clientGlobalObj.userInfo.changeUser(aUserName)
                // this.addStyleSheet();
                // sessionStorage.setItem('IS_LOGIN_DONE', 'FALSE');
                // this._showAppHideContent();
                // let endPointId = clientGlobalObj.userInfo.getActiveUser().endPointId + "_";
                // sessionStorage.setItem('offline_page_info', this.getOfflineLoginInfo(endPointId));
                // location.href = this.getActualHrefLocation() + '#';
            }
            else {
                // clientGlobalObj.userInfo.markUserInActiveAndRemoveSessionStorage();
                // window.open(sLocationForRedirect, '_blank');
            }
        }
        else if (location_href.match('addSession')) {
            // this.addStyleSheet();
            // this._showAppHideContent();
        }
        else {
            sessionStorage.setItem('offline_page_info', sOfflineLoginInfo);
            clientGlobalObj.userInfo.setActiveUserIfNoneFound();
            this.addStyleSheet();
            this._showAppHideContent();
            var elements = document.querySelectorAll('link[rel=stylesheet]');
            elements.forEach(function (element) {
                if (element.id == 'font')
                    element['disabled'] = true;
            });
        }
    }

    public addStyleSheet() {
        var head = document.getElementsByTagName('HEAD')[0];
        var link = document.createElement('link');
        link.id = 'mainStyle';
        link.rel = 'stylesheet';
        link.type = 'text/css';
        link.href = 'cdn_app/shared_1/css/style.css';
        head.appendChild(link);
    }

    public getOfflineLoginInfo(endPointId) {
        var oUserInfo = localStorage.getItem(endPointId + 'RESOLVED_USER_INFO');
        oUserInfo = JSON.parse(oUserInfo);
        var sOfflineLoginInfo = "{}";
        if (oUserInfo) {
            var oOfflineLoginInfo = {
                offline_page_username: oUserInfo['r_first_name'],
                offline_page_password: clientGlobalObj.userInfo.getUserKeyCloackInfo('LPHash'),
                //offline_login_expired: localStorage.getItem(endPointId +'LOGIN_AC_EXPIRED'),
                offline_relam: localStorage.getItem(endPointId + "realm"),
                users: JSON.parse(localStorage.getItem(endPointId + "REG_USERS")), // TODO get USER FROM USER LIST
            };
            sOfflineLoginInfo = JSON.stringify(oOfflineLoginInfo);
        }
        return sOfflineLoginInfo;
    }

    public loadAppJS() {
        if (localStorage.getItem("CONFIG_VAL") == null) {
            window['sw'].then(function () {
                sap.ui.getCore().attachInit(function () {
                    clientGlobalObj.loadScriptFile('closedmodules/LoadApp.js');
                });
            })
        } else {
            document.addEventListener('deviceready', function () {
                sap.ui.getCore().attachInit(function () {
                    clientGlobalObj.loadScriptFile('closedmodules/LoadApp.js');
                });
            })
        }
    }

    public _parseQueryParameterFromURL(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        var results = regex.exec(location.search);
        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' ')).replace(/["']/g, "");
    }


    public _setLoginSessions(endPointId) {
        var sImpersonateUser = this._parseQueryParameterFromURL('user');
        var sLoginUser = sImpersonateUser ? sImpersonateUser : clientGlobalObj.userInfo.getActiveUser().user;
        let sEndPointId = clientGlobalObj.userInfo.getActiveUser() ? clientGlobalObj.userInfo.getActiveUser().endPointId : null
        var sExistingLoginId = sessionStorage.getItem('EXISTING_LOGIN_USER_ID');
        if (sExistingLoginId != sLoginUser) {
            sessionStorage.clear();
            sessionStorage.setItem('LOGIN_USER_ID', sLoginUser);
            sessionStorage.setItem('landscape', clientGlobalObj.landscape);
            if (localStorage.getItem(sEndPointId + '_ImpersonateAuthorization'))
                sessionStorage.setItem('ImpersonateAuthorization', localStorage.getItem(sEndPointId + '_ImpersonateAuthorization'));
            if (sEndPointId && !location.href.match("addSession"))
                sessionStorage.setItem("endPointId", sEndPointId);
            var oResolvedUserInfo = JSON.parse(localStorage.getItem(endPointId + 'RESOLVED_USER_INFO'));
            if (oResolvedUserInfo) {
                sessionStorage.setItem('Tenant', oResolvedUserInfo.r_tenant_id);
            }
        }

    }


    public getLocalFileURL(filename) {
        if (clientGlobalObj.isClientCordova()) {
            var pathToCdn = localStorage.getItem('DeviceCDNDir');
            pathToCdn = pathToCdn ? pathToCdn : "";
            return pathToCdn + filename;
        }
        else {
            var segments = location.href.split('/');
            var lastIndex = null;
            if (location.href.indexOf('/fs') > -1) {
                lastIndex = 7;
            }
            else if (location.href.indexOf('/kws') > -1) {
                lastIndex = 8;
            }
            else if (location.href.indexOf("/klarion_cdn") > -1) {
                lastIndex = 9;
            }
            return location.href.split('/').slice(0, lastIndex).join('/') + "/" + filename;
        }
    }

    public getActualHrefLocation() { return location.origin + location.pathname; }


    private _hideAppShowContent(){
        clientGlobalObj.deviceReadyPromise.promise.then(() =>{
            //@ts-ignore
            document.getElementsByClassName('app')[0].style.display = "none"
            ///@ts-ignore
            document.getElementsByClassName('mainIndexContent')[0].style.display = "block"
        })
    }
    
    private _showAppHideContent(){
        clientGlobalObj.deviceReadyPromise.promise.then(() =>{
            //@ts-ignore
            document.getElementsByClassName('app')[0].style.display = "block"
            ///@ts-ignore
            document.getElementsByClassName('mainIndexContent')[0].style.display = "none"
        })
    }

    public loadComponent(){
        //loading component
    }

}
let _sample: Sample = new Sample();
clientGlobalObj.sample = _sample;
clientGlobalObj.fwSample.checkApplicationStorageQuota();
_sample.addStyleSheet();
_sample.initUi().then(() => {
    _sample.startRegistration()
    clientGlobalObj.fwSample.setRequireConfigOnRetry();
})
//@ts-ignore
window.sample = _sample;

window["LoginManager"] = {
    lock: function () {
        var elements = document.querySelectorAll('link[rel=stylesheet]');
        document.getElementById('indexMainContent').style.display = 'none'
        elements.forEach(function (element) {
            if (element.id == 'mainStyle'){
                    element["disabled"] = false;
            }   
        });
        setTimeout(function () {
            $(".mainIndexContent").css({ display: "none" });;
           
            //let b = document.getElementsByClassName('error_msg')[0].firstChild
            //document.getElementsByClassName('error_msg')[0].removeChild(b)
            document.getElementById('page_login_offline_password').value = ''
            document.getElementById('page_login_online_btn_login').disabled = false;
            $(".app").css({ display: "block" })
        }, 10);
    }
};



