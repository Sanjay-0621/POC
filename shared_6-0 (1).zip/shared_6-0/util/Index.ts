
import { UserInfo,UserProcess } from "kloBo/Adm/UserInfo";
import { KloRegistration } from "kloBo/Adm/KloRegistration";
import { KloAjax,AUTHORIZATION_TYPE } from "kloBo/kloCommon/KloAjaxHandler";
import type { IClientGlobal, USER_LIST } from "kloBo/Adm/ADMClientInterFaces"
import { System } from "kloBo/kloCommon/System/System";
import {KloLocalStorage , STORAGE_SCOPE} from "kloBo/kloCommon/KloLocalStorage"
import {LocalStorageFields} from "kloBo/KloEnums"

declare let clientGlobalObj: IClientGlobal;
declare let sap:any;
declare let klarionApp:any;
type ValueBag = { 't_name': string, 't_value': string }[];
type i8nMap = { [k: string]: string};
export class Index {
    private bFromForgetPassword: boolean = false;
    private _i8n: i8nMap;
    private sActionFrom: string = '';
    private fromNoUserForgetPassword: boolean;


    public async init(): Promise<void> {
        //check if device is rooted or not
        window["index"] =this; // Used by index.html
        let kloReg: KloRegistration = KloRegistration.getInstance();
        kloReg.checkApplicationStorageQuota(); //one time
        kloReg.checkISRooted();
        await this.setUILabel();
        clientGlobalObj.attachShowError(this._fnShowErrorPage,this);
        clientGlobalObj.attachLoadComponent(this._loadComponent,this)
        clientGlobalObj.attachOfflinePageLockMethod(this.lock,this)
        clientGlobalObj.attachForgePasswordOffline(this.onNavForgetPasswordOffline,this)
        let activeUser: UserInfo = UserInfo.getActiveUser();
        //Determine which page to load
        if (location.href.indexOf("forget_password") > 1) {
            this.bFromForgetPassword = true;
            let oUserInfo:boolean = activeUser.isValidUser();
            if (oUserInfo) {
                this.onNavForgetPasswordOffline();
            } else {
                this.onNavForgetPasswordOnline();
            }
        } else if (location.href.indexOf("signup") > 1) {
            this.onNavSignUp();
        }
        else if (activeUser?.regInfo?.IS_REGISTRATION_COMPLETED) {
            this._fnShowOnlinePage();
        }
        else {
            this._removeMsg();
            this._removeInvalidClass();
            $(".app").css({ display: "block" })
            this.showPage("page_login");
        }
        if(clientGlobalObj.isSystemSAP()){
            clientGlobalObj.loadAppJS()
            return;
        }
        let nextState:string = UserInfo.getActiveUser().getNextState();
        if (nextState == "FRESH_REGISTRATION") {
            await clientGlobalObj.deviceReadyPromise.promise;
            await this._showAppHideContent();
            return;
        }
        await clientGlobalObj.deviceReadyPromise.promise;
        if (nextState == "REGISTRATION_IN_PROGRESS" || nextState == "UPDATE_AVAILABLE") {
            clientGlobalObj.addStyleSheet();
            await this._showAppHideContent();
        } else if (nextState == "ALL_DONE") {
            this._disableApplicationCSS('mainStyle')
            UserInfo.getActiveUser().regInfo.SHOW_LOCK_SCREEN = true;
            this._showContentHideApp();
            await clientGlobalObj.loadAppJS();
            this._hideSplashScreen();//additional for mobile
            window.name = 'LI';
        } else if (nextState == "LOGIN_REQUIRED") {
            this._lockScreen();
        }
    }

    private async _lockScreen() {
        clientGlobalObj.loadAppJS();
        let lastLogin = parseInt(KloLocalStorage.getItem(LocalStorageFields.OFFLINE_LOGIN_TIME , STORAGE_SCOPE.endpoint) || '0');
        let oDeviceInfo = KloLocalStorage.getItemParsed(LocalStorageFields.DEVICE_INFO_SEND,STORAGE_SCOPE.endpoint)
        if (oDeviceInfo.t_landscape_type == "DEV" && !clientGlobalObj.isClientCordova() && window.name == 'LI' && lastLogin && (new Date().getTime() - lastLogin < 604800000 /* 7 days */) ){
            UserInfo.getActiveUser().regInfo.SHOW_LOCK_SCREEN = true;
            this._disableApplicationCSS( 'mainStyle');
        } else {
            //show offline login
            clientGlobalObj.addStyleSheet();
            await this._showAppHideContent();
            this._disableApplicationCSS('font')
            UserInfo.getActiveUser().setActiveUserIfNoneFound();// if reload during add user then to set user
        }
    }

    private async _initializei8n(): Promise<void>{
        try{
            let i8nFile = await import(`shared_${clientGlobalObj.sharedVersion}_`+clientGlobalObj.landscape+"/util/i8n")  // TODO VER how to get version here
            let sDefaultLang:string = 'en';
            let sBrowserLang:string = navigator.language;
            this._i8n = i8nFile.i8n.i8n_Klarion_registraion[sBrowserLang] ? i8nFile.i8n.i8n_Klarion_registraion[sBrowserLang] : i8nFile.i8n.i8n_Klarion_registraion[sDefaultLang];
            let _i8n:object = this._i8n;
            let _i8nMapper:object = i8nFile.i8n.i8n_Klarion_registraion["i8Mapper"]
            for (let key in _i8nMapper) {
                if(key == "otp_input"){
                    let inner_str = (_i8n[_i8nMapper[key]] as string).split("*")[0];
                    let elem = document.getElementById(key);
                    elem.innerHTML = inner_str;
                    let inner_div = document.createElement("span");
                    inner_div.className = "requiredIndicator";
                    inner_div.innerHTML = '*';
                    elem.appendChild(inner_div);
                }
                else {
                    document.getElementById(key).innerHTML = _i8n[_i8nMapper[key]];
                }
            }
            document.getElementById('login_or').innerHTML = "<hr id=\"hr-text\"data-content=\"OR Continue With\">" + _i8n["or"] + "<hr>";
        }catch(err){

        }    
    }

    public async setUILabel(): Promise<void> {
        await this._initializei8n();
        let oUIConfig = clientGlobalObj.oUIConfig;
        !oUIConfig.showSocialMedia ? $("#registerSocialMedia").css({ "display": "none" }) : null;
        !oUIConfig.showSignInCheckBox ? $("#sign_in_checkbox").css({ "display": "none" }) : null;
        !oUIConfig.showGooglePlus ? $("#btn_gplus").css({ "display": "none" }) : null;
        !oUIConfig.showLinkedIn ? $("#btn_linkedin").css({ "display": "none" }) : null;
        !oUIConfig.showTwitter ? $("#btn_twitter").css({ "display": "none" }) : null;
        !oUIConfig.showHeader ? $(".fixedHeader").css({ "display": "none" }) : null;
        !oUIConfig.showSignUp ? $("#sign_up_box").css({ "display": "none" }) : null;
        !oUIConfig.showPoweredBy ? $("#box_poweredby").css({ "display": "none" }) : null;
        !oUIConfig.showForgetPassword ? $("#div_link").css({ "display": "none" }) : null;
        !oUIConfig.showForgetPassword && !oUIConfig.showSignInCheckBox ? $("#div_fp_signcheck").css({ "display": "none" }) : null;
        !oUIConfig.showBioMetricLogin ? $("#bio-metric").css({ "display": "none" }) : null;
        !oUIConfig.showEye ? ($(".field-icon").css({
            "display": "none"
        }), $('input[type="password"]').removeClass('twoSideIcon'), $('input[type="password"]').addClass('oneSideIcon')) : null;
        !oUIConfig.showTermsAndCondition ? ($('#terms').addClass('hidden'), $('#confirm').removeClass('hidden'), $('#confirm').addClass('expended')) : null;
        !oUIConfig.showPasswordPolicy ? $("#div_pp").css({ "display": "none" }) : null;
        if (!oUIConfig.showChangeUser && !oUIConfig.showAddUser) {
            $("#page_user_info").css({ "display": "none" });
        } else if (!oUIConfig.showChangeUser) {
            $("#link_change_user").css({ "display": "none" });
            $("#page_user_info_separator").css({ "display": "none" });
        } else if (!oUIConfig.showAddUser) {
            $("#link_add_session").css({ "display": "none" });
            $("#page_user_info_separator").css({ "display": "none" });
        }

        //Floating Label events
        let formInputs:JQuery<HTMLElement> = $('input[type="text"],input[type="password"],input[type="number"],input[type="textfield"],input[type="tel"]');
        formInputs.focus(function () {
            $(this).parent().children('p.formLabel').addClass('formTop');
        });
        formInputs.focusout(function () {
            //@ts-ignore
            let value: string = $(this).val();
            if ($.trim(value).length == 0) {
                $(this).parent().children('p.formLabel').removeClass('formTop');
            }
        });
        $('p.formLabel').click(function () {
            $(this).parent().children('input.inputstyle').focus();
        });

        $(".fixedBox").css({ display: "block" });
        //Click of eye icons in password
        $('.field-icon').click(function () {
            let parent:HTMLElement = $(this).parent()[0];
            let input:JQuery<HTMLElement> = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
                parent.children[3].setAttribute('style', "display:none")
                parent.children[4].setAttribute('style', "display:block")
            } else {
                input.attr("type", "password");
                parent.children[3].setAttribute('style', "display:block")
                parent.children[4].setAttribute('style', "display:none")

            }
        });
    }

    /* * on Click of login */
    public async onClickLoginRegistration(): Promise<void> {
        $(".loading").removeClass("hidden");
        let _i8n = this._i8n;
        this._enable_disable_button(true);
        this.sActionFrom = "page_login";
        let oUserValueControl: JQuery<HTMLElement> = $("#page_login_inp_mob_user");
        let oPasswordControl: JQuery<HTMLElement> = $("#page_login_inp_mob_password");
        let sUserId:string | number | string[] = oUserValueControl.val();
        let sPassword:string | number | string[] = oPasswordControl.val();
        if (!sUserId) {
            this._fnShowErrorMsg(oUserValueControl, _i8n["user_id"]);
            $(".loading").addClass("hidden");
            return;
        }
        if (!sPassword) {
            this._fnShowErrorMsg(oPasswordControl, _i8n["enter_password"]);
            $(".loading").addClass("hidden");
            return;
        }
        //Validates password on click of login
        //await this._fnValidatePassword(sPassword, oPasswordControl);
        let oDeviceRegInfo = {
            "r_action": "resolve_user",
            "is_sign_up": false,
            "properties": [{ t_name: "page_register_inp_mob", t_value: sUserId }, { t_name: "is_sign_up", t_value: "false" }, { t_name: "APP_ID", t_value: "browser" }]
        };
        await this._doRegister(oDeviceRegInfo,false, oUserValueControl, sPassword as string, false);
    }

    /** on click of next in signup page*/
    public async onClickSignUpNext(): Promise<void> {
        this._enable_disable_button(true);
        this.sActionFrom = "page_register";
        let validationControlMobNo:JQuery<HTMLElement> = $("#page_register_inp_mob");
        let validationControlUserID: JQuery<HTMLElement> = $("#page_register_user_id");
        let validationControlBPID: JQuery<HTMLElement> = $("#page_register_entity_id");
        let iValidMobileNumber: boolean = validationControlMobNo.val() ? this.validatePhone(validationControlMobNo.val() as string) : false;
        let iUserID = validationControlUserID.val() ? validationControlUserID.val() as string : null;
        let iBPID = validationControlBPID.val() ? validationControlBPID.val() as string : null;
        // Note: Register only if mobile number and user id is present.
        if (iValidMobileNumber && iUserID && iBPID) {
            let aValueBag:ValueBag = this.getValueBagFromDOM("page_register");
            aValueBag.push({
                t_name: "APP_ID",
                t_value: "browser"
            });
            let oDeviceRegInfo = {
                "properties": aValueBag
            };
            this.fromNoUserForgetPassword = true;
            await this._doRegister(oDeviceRegInfo,true ,validationControlMobNo, null, true, null);
        }  // the case for mobile number not present was not given. Added it 
        else if (!iValidMobileNumber) {
            this._fnShowErrorMsg(validationControlMobNo, this._i8n["enter_mobile_no"]);
        } // case handle the user id being not present modified previous else to else if
        else if(!iUserID){
            this._fnShowErrorMsg(validationControlUserID, this._i8n["user_id"]);
        }
        else if(!iBPID){
            this._fnShowErrorMsg(validationControlBPID, this._i8n["16"]);
        }
        else if(!iValidMobileNumber && !iUserID && !iBPID){
            this._fnShowErrorMsg(validationControlMobNo, this._i8n["Fill all the fields"]);
        }
        // Fallthrough case, should not happen
        else {
            this._fnShowErrorMsg(validationControlMobNo, "Unexpected Error in Registration Process");
        }
    };

    private async _doRegister(oDeviceRegInfo: object,isSignUp:boolean ,validationControl: JQuery<HTMLElement>, sPassword?: string,isNoUserForgotPwd?: boolean, headerBag?: any): Promise<void> {
        try {
            let userInfo:UserInfo = UserInfo.getActiveUser();
            let response = await userInfo.performRegisterCall(oDeviceRegInfo,isSignUp,sPassword, isNoUserForgotPwd,headerBag);
            if (response.reg_status === "OTP" || response.reg_status === "TWO_OTP") {
                if (this.sActionFrom == 'page_register') {
                    (<HTMLElement>document.getElementsByClassName('page_cp_user_otp_div')[0]).style.display = "block";
                    (<HTMLElement>document.getElementsByClassName('page_cp_resend_otp_div')[0]).style.display = "block";
                    response.reg_status === "TWO_OTP" ? (<HTMLElement>document.getElementsByClassName('page_cp_manager_otp_div')[0]).style.display = "block" : "";
                    await this.showPasswordPolicy();
                    this.showPage("page_confirm_password");
                    this._fnShowSuccessMsg(this._i8n["successfull_otp"]);
                }else{
                    response.reg_status === "TWO_OTP" ? (<HTMLElement>document.getElementsByClassName('page_otp_manager_otp_div')[0]).style.display = "block" : "";
                    this.showPage("page_otp");
                    this._fnShowSuccessMsg(this._i8n["successfull_otp"]);
                }
               
            } else if (response.reg_status === "APPROVED") {
                if (this.sActionFrom == 'page_register') {
                    await this.showPasswordPolicy();
                    this.showPage("page_confirm_password");
                } else {
                    this._showUserConfirmPage();
                }
            }
            else if(response.reg_status === "APPROVAL_REQUIRED"){
                this._fnShowSuccessMsg(this._i8n["18"]);
            }
            else if(response.reg_status === "ACTIVE"){
                this._showUserConfirmPage();
            }
            else {
                this._fnShowErrorPage();
            }
        } catch (sErrorMsg) {
            try {
                let oErrorMsg:any = JSON.parse(sErrorMsg);
                if (oErrorMsg.code == 15) {
                    this._fnShowErrorMsg(validationControl, this._i8n[oErrorMsg.code] + oErrorMsg.message);
                } else {
                    this._fnShowErrorMsg(validationControl, this._i8n[oErrorMsg.code]);
                }
            } catch (e) {
                this._fnShowErrorMsg(validationControl, sErrorMsg);
            }
        }
    }

    private async _fnValidatePassword(sPassword: string, oPasswordControl: JQuery<HTMLElement>): Promise<void> {
        let _this = this;
        try {
            await (UserInfo.getActiveUser()).validate(sPassword);
        } catch (e) {
            _this._fnShowErrorMsg(oPasswordControl, "Invalid Password");
        }
    }

    public async onValidateOTP(): Promise<void> {
        let oUserValueControl:JQuery<HTMLElement> = $("#page_otp_inp_otp");
        let oUserInfo: UserInfo = UserInfo.getActiveUser();
        let sUserOptEnterted:string = <string>oUserValueControl.val();
        let oManageValueControl:JQuery<HTMLElement> = $("#page_otp_inp_otp_manager");
        let sManagerOtpEntered:string = <string>oManageValueControl.val();
        let isTwoOtp:boolean = (<HTMLElement>document.getElementsByClassName('page_otp_manager_otp_div')[0]).style.display == "none" ? false :true;
        if (!sUserOptEnterted) {
            this._fnShowErrorMsg(oUserValueControl, this._i8n["enter_otp"]);
            return;
        }
        if(!sManagerOtpEntered && isTwoOtp){
            this._fnShowErrorMsg(oManageValueControl, this._i8n["enter_otp"]);
            return;
        }
        //validates otp on click of next in otp page
        try {
            await oUserInfo.validateOTPP(sUserOptEnterted,sManagerOtpEntered);
            if (this.sActionFrom === "page_login") {
                this._showUserConfirmPage();
            } 
            //else if (this.sActionFrom === "page_register") {
            //     this.showPage("page_confirm_password");
            // }
        }
        catch (sErrorMsg) {
            this._fnShowErrorMsg(oUserValueControl, this._i8n[JSON.parse(sErrorMsg.responseText).code]);
        }
    };

    public async onClickConfirmPassword(): Promise<void> {
        this._enable_disable_button(true);
        let oPasswordControl:JQuery<HTMLElement> = $("#page_confirm_password_inp_pswd");
        let oCnfPasswordControl:JQuery<HTMLElement> = $("#page_confirm_password_inp_cnfpswd");
        let oUserOtpControl:JQuery<HTMLElement> = $("#page_confirm_password_inp_otp_user");
        let oManagerOtpControl:JQuery<HTMLElement> = $("#page_confirm_password_inp_otp_manager");
        let isOTP:boolean = (<HTMLElement>document.getElementsByClassName('page_cp_user_otp_div')[0]).style.display == "none" ? false :true;
        let isTwoOtp:boolean = (<HTMLElement>document.getElementsByClassName('page_otp_manager_otp_div')[0]).style.display == "none" ? false :true;
        let sPassword:string | number | string[] = oPasswordControl.val();
        let sPasswordConf:string | number | string[] = oCnfPasswordControl.val();
        let sUserOtp:string | number | string[] = oUserOtpControl.val();
        let sManagerOtp:string | number | string[] = oManagerOtpControl.val();
        if(!sUserOtp && isOTP){
            this._fnShowErrorMsg(oUserOtpControl, this._i8n["enter_otp"]);
            return;
        }
        if(!sManagerOtp && isTwoOtp){
            this._fnShowErrorMsg(oManagerOtpControl, this._i8n["enter_otp"]);
            return;
        }
        if (!sPassword) {
            this._fnShowErrorMsg(oPasswordControl, this._i8n["enter_password"]);
            return;
        }
        if (!sPasswordConf) {
            this._fnShowErrorMsg(oCnfPasswordControl, this._i8n["confirm_password"]);
            return;
        }

        if (sPassword !== sPasswordConf) {
            this._fnShowErrorMsg(oCnfPasswordControl, this._i8n["password_not_matching"]);
            return;
        }
        await this._confirmPassword(sPassword as string,sUserOtp as string,sManagerOtp as string ,oPasswordControl)
    }

    private async _confirmPassword(sPassword:string,sUserOtp:string,sManagerOtp,oPasswordControl:JQuery<HTMLElement>): Promise<void> {
        let oUserInfo: UserInfo = UserInfo.getActiveUser();
        await this._fnValidatePassword(sPassword, oPasswordControl);
        let res = null;
        try {
            if(this.sActionFrom == "forget_password"){
                await oUserInfo.onResetPassword(oUserInfo.r_login_id,sUserOtp,sManagerOtp,sPassword);
            }else{
                res = await oUserInfo.validateOtpAndCreatePassword(sUserOtp,sManagerOtp,sPassword);
            }
            await oUserInfo.login(UserInfo.getActiveUser().r_login_id,sPassword,UserInfo.getActiveUser().realmId);
            if(res && res.r_status == 'ACTIVE'){
                this._showUserConfirmPage();
                this.fromNoUserForgetPassword = true;
                return;
            }
            if (this.bFromForgetPassword) {
                this._showUserConfirmPage();
                this.fromNoUserForgetPassword = true;
            } else {
                if (UserInfo.getActiveUser()?.r_endpoint_id && UserInfo.getActiveUser()?.regInfo.IS_ROT_SETUP_COMPLETED) {
                    let kloReg:KloRegistration = KloRegistration.getInstance();
                    kloReg.navigateToMainApp();
                } else {
                    this._fnShowOnlinePage();
                }
            }
        } catch (sErrorMsg) {
            this._fnShowErrorMsg(oPasswordControl, sErrorMsg);
        }
    }

    /* on click of add user*/
    private onNavAddUser() {
        this.showPage("page_login")
        UserInfo.getActiveUser().markUserInActiveAndRemoveSessionStorage();
    };

    /** on click of change user*/
    private onNavChangeUser = function () {
        $('.collection-item').remove();
        let userList: Array<USER_LIST> = UserInfo.getUserList();
        let aRegUsers:string[] = [];
        userList.forEach(user => {
            aRegUsers.push(user.user)
        })
        if (aRegUsers.length > 0) {
            aRegUsers.forEach(function (item) {
                $('#users_list').append('<a href="#!" class="collection-item">' + item + '</a>');
            });
        }
        this.showPage('page_switch_user');
    };

    /* on click of item in users list*/
    private onClickUsersList = function (event) {
        let userid:string = event.target.innerHTML;
        UserInfo.getActiveUser().changeUser(userid);
        this._initializei8n();
        this._fnShowOnlinePage();
    };

    /**on Click of login*/
    public onClickLogin(): void {
        this._enable_disable_button(true);
        let isUpdateAvailable: boolean = UserInfo.getActiveUser()?.regInfo.UPDATE_AVAILABLE
        if (UserInfo.getActiveUser()?.r_endpoint_id && UserInfo.getActiveUser()?.regInfo.START_RECOVERY) {
            this.onLoginOnline();
        }
        else if (UserInfo.getActiveUser()?.regInfo.IS_REGISTRATION_COMPLETED && UserInfo.getActiveUser()?.regInfo.IS_ROT_SETUP_COMPLETED && !isUpdateAvailable) {
            this.onLoginOffline();
        } else {
            this.onLoginOnline();
        }
    }

    /** on  login offline*/
    public async onLoginOffline(): Promise<void> {
        let oPassword = <string>$("#page_login_offline_password").val();
        let userInfo: UserInfo = UserInfo.getActiveUser();
        if (oPassword == "recover") { 
            UserInfo.getActiveUser().recoverApp();
        }
        else {
            if (userInfo.isValidPassword(oPassword) && !clientGlobalObj.isSystemSAP()) {
                KloLocalStorage.setItem(LocalStorageFields.OFFLINE_LOGIN_TIME,new Date().getTime().toString(),STORAGE_SCOPE.endpoint);
                userInfo.regInfo.SHOW_LOCK_SCREEN = true;
                window.name = 'LI';
                this._disableApplicationCSS( 'mainStyle')
                this._showContentHideApp();
            }
            else {
                this._fnShowErrorMsg($("#page_login_offline_password"), this._i8n["invalid_password"])
            }
        }
    };

    /** on  login online*/
    public async onLoginOnline() {
        let oPasswordControl:JQuery<HTMLElement> = $("#page_login_offline_password");
        let sPassword:string | number | string[] = oPasswordControl.val();
        if (!sPassword) {
            this._fnShowErrorMsg(oPasswordControl, this._i8n["enter_password"]);
            return;
        }
        await this._fnValidatePassword(sPassword as string, oPasswordControl);
        let userInfo:UserInfo = UserInfo.getActiveUser();
        let isRegistration:boolean =false;
        try{
            if(!userInfo?.regInfo.IS_REGISTRATION_COMPLETED || userInfo?.regInfo.UPDATE_AVAILABLE){
                isRegistration = true;
                await this._attachProgressCallbacks();
                clientGlobalObj.resolveAcceptOrRejectPromise();
            }
            let result:UserProcess = await userInfo.handleUserProcess();
            if(result != UserProcess.NO_PENDING_PROCESS){
                if(!isRegistration){
                    await this._attachProgressCallbacks() 
                    clientGlobalObj.resolveAcceptOrRejectPromise();
                }
            }else{
                this._showUserConfirmPage();
                this.fromNoUserForgetPassword = true;
            }
            
        }catch(e){
            this._fnShowErrorPage();
        }
    }

    /*show error message in dev model*/
    public _fnShowErrorMsgInDevModel(oControl: JQuery<HTMLElement>, errorText: string) {
        let oJQueryElement:any = null;
        oJQueryElement = arguments[0];
        let sText:any = arguments[1];
        this._enable_disable_button(false);
        this._removeInvalidClass();
        this._removeMsg();
        if (oJQueryElement) {
            oJQueryElement.addClass("invalid");
            oJQueryElement.focus();
        }
        if (sText) {
            $(".devModel").children("form").before('<div class="error_msg"><span><i class="fas fa-exclamation-circle messageIcon"></i>' + sText + '</span></div>');
        }
    }

    /**
     * Shows Error message
     */
    public _fnShowErrorMsg(oControl: JQuery<HTMLElement>, errorText: string) {
        let oJQueryElement:any = null;
        let sText:any = null;
        this._enable_disable_button(false);
        if (arguments.length == 1) {
            sText = arguments[0];
        } else if (arguments.length == 2) {
            oJQueryElement = arguments[0];
            sText = arguments[1];
        }
        typeof sText == 'object' ? sText = sText.message : ""
        sText.includes('Error:') ? sText = sText.replaceAll('Error:','') : ""
        sText = sText.trimStart()
        sText = typeof sText != "string" ? "Unexpected Exception" : sText;
        this._removeInvalidClass();
        this._removeMsg();
        if (oJQueryElement) {
            oJQueryElement.addClass("invalid");
            oJQueryElement.focus();
        }
        if (sText) {
            $(".expanded").children("form").before('<div class="error_msg"><span><i class="fas fa-exclamation-circle messageIcon"></i>' + sText + '</span></div>');
        }
    }

    /*Shows success message*/
    private _fnShowSuccessMsg(sText?: string): void {
        this._enable_disable_button(false);
        this._removeInvalidClass();
        this._removeMsg();
        if (sText) {
            $(".expanded").children("form").before('<div class="success_msg"><span><i class="fas fa-check-circle messageIcon"></i>' + sText + '</span></div>');
        }
    }

    /*Shows error page*/
    private _fnShowErrorPage(err?:any): void {
        console.log(err);
        this.showPage("page_error");
        $('.content').addClass("error_page");
    }

    /*Shows user onfirm page*/
    private _showUserConfirmPage(): void {
        let oUserInfo:UserInfo = UserInfo.getActiveUser();
        this.showPage("page_confirm_user");
        $("#page_confirm_user_inp_firstname").val(oUserInfo.r_first_name);
        $("#page_confirm_user_inp_lastname").val(oUserInfo.r_last_name);
        $("#page_confirm_user_inp_mobileno").val(oUserInfo.r_mobile_no);
        $("#page_confirm_user_inp_email").val(oUserInfo.r_email);
        //$("#page_confirm_user_inp_role").val(oUserInfo.role);
        $(".content").addClass("expand_confirm_user");
    }
    /**
 * on click enter when input is focused will invoke button click
 * * @return {string} form factor
 */
    public onInputKeyPress(event): void {
        if (event.keyCode === 13) {
            if (event.currentTarget.id == "page_login_offline_password") {
                event.preventDefault();
                document.getElementById("page_login_online_btn_login").click();
            } else if (event.currentTarget.id == "page_confirm_password_inp_pswd" || event.currentTarget.id == "page_confirm_password_inp_cnfpswd") {
                event.preventDefault();
                document.getElementById("page_confirm_password_btn_ok").click();
            } else if (event.currentTarget.id == "page_login_inp_mob_user" || event.currentTarget.id == "page_login_inp_mob_password") {
                event.preventDefault();
                document.getElementById("btn_login").click();
            } else if (event.currentTarget.id == "page_register_inp_mob" || event.currentTarget.id == "page_register_entity_id" || event.currentTarget.id == "page_register_user_id") {
                event.preventDefault();
                document.getElementById("btn_next_reg_mob").click();
            } else if (event.currentTarget.id == "page_otp_inp_otp") {
                event.preventDefault();
                document.getElementById("page_otp_btn_otp").click();
            }

        }
    }

    /**on Click of Accept button*/
    public async onClickAccept(): Promise<void> {
        this._enable_disable_button(true);
        clientGlobalObj.resolveAcceptOrRejectPromise();
        let userInfo:UserInfo = UserInfo.getActiveUser();
        if (this.fromNoUserForgetPassword) {
            userInfo.handleUserProcess();
        }
        UserInfo.getActiveUser().regInfo.IS_REGISTRATION_COMPLETED = true;
        await this._attachProgressCallbacks();
    };

    /** Progress indicator callback*/
    private async _attachProgressCallbacks(): Promise<void> {
        let progressbar = await import("kloExternal_"+clientGlobalObj.landscape + "/progressbar");
        if (!$('#page_progress').hasClass('expanded')) {
            let progress_indicator:any = new progressbar.Circle('#progress_bar', {
                color: '#2196F3',
                strokeWidth: 2.1,
                svgStyle: {
                    width: '160px',
                    height: '160px'
                }
            });
            $(".content").addClass("expand_progress");
            this.showPage("page_progress");
            setInterval(() => {
                let kloReg:KloRegistration = KloRegistration.getInstance();
                let statusPercentage:number = kloReg.getProgessStatus();
                progress_indicator.animate(statusPercentage / 100);
                progress_indicator.setText(Math.round(statusPercentage) + "%");
            }, 1000)
        }
    }

    /**on Click of Reject button*/
    public onClickReject(): void {
        let kloReg:KloRegistration = KloRegistration.getInstance();
        this._enable_disable_button(true);
        kloReg.cancelDeivceRegistration();
    };

    /* Shows login page online*/
    private async _fnShowOnlinePage(): Promise<void> {
        let oUserInfo: UserInfo = UserInfo.getActiveUser();
        this.enableFingerPrint();
        $("#page_login_online_userinfo span").html(this._i8n["welcome_note"] + " " + oUserInfo[clientGlobalObj.oUIConfig.welcomeNoteProperty] + ",");
        this.showPage("page_login_online");
    }

    /*on Click of forget Password*/
    public onNavForgetPasswordOnline(): void {
        this.bFromForgetPassword = true;
        let loggedInUser:string = UserInfo.getActiveUser().r_login_id;
        this.showPage("page_forgot_password");
        let userInfo:UserInfo = UserInfo.getActiveUser();
        if (userInfo?.r_endpoint_id && userInfo?.regInfo.IS_REGISTRATION_COMPLETED) {
            //@ts-ignore
            $("#page_fp_inp_mob")[0].setAttribute("readonly", true);
            //@ts-ignore
            $("#page_fp_inp_mob")[0].value = loggedInUser;
            //@ts-ignore
            let sId:string = $("#page_fp_inp_mob")[0].parentNode.getElementsByTagName('p')[0].id;
            $('#' + sId).addClass('formTop');
        }
        $("#link_signin_fp").show();
        $("#link_back_fp").hide();
    };

    /*on Click of Back in page registration through mobile number*/
    public onNavBack(): void {
        this._fnShowOnlinePage();
    };

    public onNavForgetPasswordOffline(): void {
        this.bFromForgetPassword = false;
        let loggedInUser:string = UserInfo.getActiveUser().r_login_id;
        this.showPage("page_forgot_password");
        let userInfo: UserInfo = UserInfo.getActiveUser();
        if (userInfo?.r_endpoint_id && userInfo?.regInfo.IS_REGISTRATION_COMPLETED) {
            //@ts-ignore
            $("#page_fp_inp_mob")[0].setAttribute("readonly", true);
            //@ts-ignore
            $("#page_fp_inp_mob")[0].value = loggedInUser;
            //@ts-ignore
            let sId:string = $("#page_fp_inp_mob")[0].parentNode.getElementsByTagName('p')[0].id;
            $('#' + sId).addClass('formTop');
        }
        $("#link_signin_fp").hide();
        $("#link_back_fp").show();
    }

    public onClosePasswordPolicy(): void{
        document.getElementById("modal_pp").style.display = "none"
    }

    /* on click of next in forget password page*/
    public async onClickFpNext(): Promise<void> {
        this._enable_disable_button(true);
        let validationControl:JQuery<HTMLElement> = $("#page_fp_inp_mob");
        if (validationControl.val()) {
            this.sActionFrom = "forget_password";
            let loggedInUserEPI:string | null = UserInfo.getActiveUser()?.r_login_id || null;
            //UserInfo.getActiveUser().r_login_id = <string>validationControl.val();
            document.getElementById('conf_register').innerHTML = 'Reset Password'
            if (!loggedInUserEPI) {
                let oDeviceRegInfo = {
                    "r_action": "resolve_user",
                    "is_sign_up": false,
                    "properties": [{ t_name: "page_register_inp_mob", t_value: validationControl.val() },
                    { t_name: "is_sign_up", t_value: "false" }, { t_name: "APP_ID", t_value: "browser" }]
                };
                await UserInfo.getActiveUser().performRegisterCall(oDeviceRegInfo, false,null, true,null);
            }
            let res = await UserInfo.getActiveUser().onForgetPassword(<string>validationControl.val());
            res.reg_status === "OTP" ? (<HTMLElement>document.getElementsByClassName('page_cp_user_otp_div')[0]).style.display = "block" : ""
            res.reg_status === "TWO_OTP" ? (<HTMLElement>document.getElementsByClassName('page_otp_manager_otp_div')[0]).style.display = "block" : "";
            await this.showPasswordPolicy();
            this.showPage("page_confirm_password");
        } else {
            this._fnShowErrorMsg(validationControl, this._i8n["user_id"]);
        }
    }

    public validatePhone(mNum: string): boolean {
        let mNumber:string = mNum;
        if ((mNumber.match(/^(?:\+\d+[- ])?\d{10}$/) && !(mNumber.match(/0{9,}/)))) {
            return true;
        }
        return false;
    };

    /**
      * Build value bag from DOM form elements
      * @param {string} formid ID of form element
      * @return {object} it will take all the form elements and with its id,creates an
      *         object and holdes corresponding value
      **/

    public getValueBagFromDOM(formid: string): ValueBag {
        let arrayValueBag: ValueBag = [];
        //expected tags to be found within form-> finds also in deep dom structure
        $("#" + formid).find("select,input,textarea,button,optgroup,fieldset,label,output").each(function (index: number, oItem: any) {
            let valuebag: any = {};
            let key:string = oItem.id;
            valuebag["t_name"] = key;
            valuebag["t_value"] = $("#" + key).val();
            arrayValueBag.push(valuebag);
        });
        return arrayValueBag;
    };

    /**on Click of resend OTP*/
    public async fnResendOtp(): Promise<void> {
        this._enable_disable_button(true);
        let otpControl:JQuery<HTMLElement> = $("#page_otp_inp_otp");

        let oUserInfo:UserInfo = UserInfo.getActiveUser();
        try {
            await oUserInfo.resendOTPP();
            this._fnShowSuccessMsg(this._i8n["successfull_otp"]);
        }
        catch (sErrorMsg) {
            this._fnShowErrorMsg(otpControl, this._i8n[JSON.parse(sErrorMsg).code]);
        }
    }

    /**on Click of Sign UP*/
    public onNavSignUp(): void {
        this.bFromForgetPassword = false;
        this.showPage("page_register");
    };
    private _removeMsg(): void {
        $(".error_msg").remove();
        $(".success_msg").remove();
    }
    private _removeInvalidClass(): void {
        $(".invalid").removeClass('invalid');
    }
    private showPage(id: string): void {
        let sSelectedDomId:string = $(".expanded").attr('id');
        id != "page_confirm_user" ? this._clear_form_elements(id) : null;
        this._enable_disable_button(false);
        this.hidePage(sSelectedDomId);
        let pageid:string = "#" + id;
        this._removeInvalidClass();
        this._removeMsg();
        $(pageid).removeClass("hidden");
        $(pageid).addClass("expanded");
    }
    private _clear_form_elements(id: string): void {
        jQuery("#" + id).find(':input').each(function (evt: any) {
            switch (evt.type) {
                case 'password':
                case 'text':
                case 'textarea':
                case 'file':
                case 'select-one':
                case 'select-multiple':
                case 'date':
                case 'number':
                case 'tel':
                case 'email':
                    jQuery(evt).val('');
                    evt.getAttribute("readonly") ? evt.setAttribute("readonly", false) : null;
                    if (evt.parentNode.getElementsByTagName('p')[0]) {
                        let sId:any = evt.parentNode.getElementsByTagName('p')[0].id;
                        $('#' + sId).removeClass('formTop');
                    }
                    break;
                case 'checkbox':
                case 'radio':
                    evt.checked = false;
                    break;
            }
        });
    }

    private _enable_disable_button(bDisable: boolean): void {
        let sSelectedDomId:string = $(".expanded").attr('id');
        let a:JQuery<HTMLElement> = jQuery("#" + sSelectedDomId).find(':button');
        a.prop("disabled", bDisable);
    }
    private hidePage(id: string): void {
        let pageid:string = "#" + id;
        $(pageid).addClass("hidden");
        $(pageid).removeClass("expanded");
    }

    /** on Click of Sign In in page registration through mobile number */
    public onNavSignIn(): void {
        this.showPage("page_login");
    };

    public acceptFunction(): void {
        $('#terms').addClass('hidden');
        $('#confirm').removeClass('hidden');
        $('#confirm').addClass('expended');
    }


    private _hideSplashScreen(): void { navigator["splashscreen"] && navigator["splashscreen"].hide() }

    private _disableApplicationCSS(cssElementId: string): void{
        let elements: NodeListOf<Element> = document.querySelectorAll('link[rel=stylesheet]');
        elements.forEach(function (element) {
            if (element.id == cssElementId)
                element['disabled'] = true;
        });
    }

    private async _showAppHideContent(): Promise<void> {
        await clientGlobalObj.deviceReadyPromise.promise;
        document.getElementsByClassName('mainIndexContent')[0].setAttribute('style','display:none')
        document.getElementsByClassName('app')[0].setAttribute('style','display:block')
    }

    private async _showContentHideApp(): Promise<void> {
        await clientGlobalObj.deviceReadyPromise.promise;
        document.getElementsByClassName('mainIndexContent')[0].setAttribute('style','display:block;height:100%')
        document.getElementsByClassName('app')[0].setAttribute('style','display:none')
    }

    private async lock(): Promise<void>{
        let elements: NodeListOf<Element> = document.querySelectorAll('link[rel=stylesheet]');
        document.getElementById('indexMainContent').style.display = 'none'
        elements.forEach(function (element) {
            if (element.id == 'mainStyle') {
                element["disabled"] = false;
            }
        });
        await this.enableFingerPrint();
        setTimeout(function () {
            $(".mainIndexContent").css({ display: "none" });;
            //let b = document.getElementsByClassName('error_msg')[0].firstChild
            //document.getElementsByClassName('error_msg')[0].removeChild(b)
            (<HTMLInputElement>document.getElementById('page_login_offline_password')).value = "";
            (<HTMLInputElement>document.getElementById('page_login_online_btn_login')).disabled = false;
            $(".app").css({ display: "block" })
        }, 10);
    }

    private async _loadComponent(): Promise<void> {
        //loading component
        await this._seam4Component();
    }

    //========================Passowrd Policy ===========================

    private async showPasswordPolicy(): Promise<void>{
        let passwordPolicies:{[key:string]:string} = await UserInfo.getActiveUser().getPoliciesFromServer();
        let policylist: HTMLLIElement[] = [];
        let crossMark:string = '&#10006;'
        for(let policy in passwordPolicies){
            let li = document.createElement('li')
            li.className= '"pass-popover-list-content'
            li.innerHTML = `<span class="pass-check-mark">${crossMark}</span>${passwordPolicies[policy]}`
            li.setAttribute('policy',policy)
            li.setAttribute('isPass','0');
            policylist.push(li);
        }
        let policyElementList = document.getElementById('pass-popover-list')
        policylist.forEach(policy =>{
            policyElementList.append(policy);
        })
    }

    public async validatePasswordPolicy(): Promise<void>{
        let policyList:HTMLCollection = document.getElementById('pass-popover-list').children
        let oPasswordControl:JQuery<HTMLElement> = $("#page_confirm_password_inp_pswd");
        let sPassword:string = <string>oPasswordControl.val();
        let result:{ isPass: true, description: "", Err: Array<{Policy:string}>}= await UserInfo.getActiveUser().validate(sPassword);
        let errList:string[] = result.Err.map(e => e.Policy);
        let tickMark:string = '&#10004';
        let crossMark:string = '&#10006;'
        let passPopover = document.getElementsByClassName('pass-popover')[0]
        if(passPopover.classList.value.includes('hidden') && !passPopover.classList.value.includes('validationCompleted'))
            passPopover.classList.remove('hidden')
        let isPassCount:number = 0;
        for(let i=0;i<policyList.length;i++){
            if(!errList.includes(policyList[i].getAttribute('policy'))){
                policyList[i].children[0].innerHTML = tickMark;
                policyList[i].children[0].setAttribute('style','color:green');
                policyList[i].setAttribute('isPass','1');
            }else{
                policyList[i].setAttribute('isPass','0');
                policyList[i].children[0].innerHTML = crossMark;
                policyList[i].children[0].setAttribute('style','color:red');
            }
            isPassCount += parseInt(policyList[i].getAttribute('isPass'));
            if(isPassCount == policyList.length){
                passPopover.classList.add('hidden')
                passPopover.classList.add('validationCompleted')
            }else{
                passPopover.classList.remove('hidden')
                passPopover.classList.remove('validationCompleted')
            }
        }
    }
    // =========== Finger Print ==============================
    public async bioMetricValidation(): Promise<void>{
        let userInfo = UserInfo.getActiveUser()
        let result = await userInfo.bioMetricValidation();
        if(result.isSuccess){
            userInfo.regInfo.SHOW_LOCK_SCREEN = true;
            this._disableApplicationCSS( 'mainStyle')
            this._showContentHideApp();
        }else{
            this._fnShowErrorMsg($("#page_login_offline_password"),result.msg);
        }
            
    }

    private async enableFingerPrint(): Promise<void>{
        if(await UserInfo.getActiveUser().isBioMetricAvailable()){
            document.getElementById('bio-metric').classList.remove('hidden')
            let bioMetricIcon = document.getElementsByClassName('bio-metric-icon')[0]
            let bioMetricText = document.getElementById('bio-metric-text');
            if(System.gi_RTS().isClientCordovaIOS){
                bioMetricIcon.textContent = 'face_unlock'
                bioMetricText.textContent = 'Or Login using Face Recognition'
            }else{//android finger print
                bioMetricIcon.textContent = 'fingerprint'
                bioMetricText.textContent = 'Login using Finger Print'
            }
        }
    }

    //========================= Seam4 ============================
    
    private async _isSAPSessionValid():Promise<boolean>{
        let data1 = {
            "id": " ",
            "message": [{
                "header": {
                    "msg_id": "1561616024855",
                    "ref_id": " ",
                    "s_tenant_id": 0,
                    "src_app": " ",
                    "src_app_ver": "0",
                    "dst_app": "seam4",
                    "dst_app_ver": "1",
                    "object_type": "0",
                    "fromendpointid": " ",
                    "toendpointid": " ",
                    "src_bo": " ",
                    "dst_bo": " ",
                    "no_sequence": 0,
                    "brand": 0,
                    "bo_key": " ",
                    "forcesend": false,
                    "mw_version": 0,
                    "modified_by": " "
                },
                "body": "",
                "response": [],
                "dependent_entity": []
            }]
        };
        let kloAjax = KloAjax.getInstance();
        let url = System._instance.getServerURL() + "/sap/opu/odata/mvn/kb_gw_service_srv/MESSAGEPROCESS"
        let headerBag = {"X-Requested-With": "XMLHttpRequest","Accept":"application/json","Content-Type":"application/json" }
        try{
            await kloAjax.perFormAction(AUTHORIZATION_TYPE.RUNTIME, { url: url, method: "POST", data: data1, headers: headerBag });
            return true;
        }
        catch(err){
            return false;
        }
    }


    private async _seam4Component(){
        if(await this._isSAPSessionValid()){
            window["SeamApp"] = klarionApp
            jQuery["sap"].registerModulePath("Massetic", "cdn_app/seam4_1/massetic");
            jQuery["sap"].registerModulePath("Seam",  "cdn_app/seam4_1/Seam4Adm");
            jQuery["sap"].registerModulePath('sap', `closedmodules/openUI5_${clientGlobalObj.sapUIVersion}/resources/sap/`);
            jQuery["sap"].registerModulePath("KloRoot/kloTouch", "closedmodules/kloTouch_6");
            jQuery["sap"].registerModulePath("kloTouch_6", "closedmodules/kloTouch_6");
            jQuery["sap"].registerModulePath('jquery.sap.sjax-dbg', `closedmodules/openUI5_${clientGlobalObj.sapUIVersion}/resources/jquery.sap.sjax-dbg`);
            this._loadSeam4Component();
        }else{
            // go to SAP locked screen 
        }
    }

    private _loadSeam4Component(){
        new sap.ui.core.ComponentContainer("KloComponent", {
            name: "Seam",
            async: true,
            height: "100%",
            handleValidation: true,
            propagateModel: true,
        }).addStyleClass("sapUiSizeCompact").placeAt("indexMainContent");
    }

}