// entity_base.ts 
