declare const mm_setting_group: {
    other: {
        group_id: string;
        icon: string;
        sq: number;
        title: string;
        s_flavor_variant: string;
    };
    general: {
        group_id: string;
        icon: string;
        sq: number;
        title: string;
        s_flavor_variant: string;
    };
    display: {
        group_id: string;
        icon: string;
        sq: number;
        title: string;
        s_flavor_variant: string;
    };
    basic: {
        group_id: string;
        icon: string;
        sq: number;
        title: string;
        s_flavor_variant: string;
    };
};
export default mm_setting_group;
