define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var mm_setting_group = { "gdfhg": { "group_id": "gdfhg", "icon": "sap-icon://accept", "sq": 2, "title": "hgf", "s_flavor_variant": "5-shared-1", "fo": "shared" }, "hddgf": { "group_id": "hddgf", "icon": "sap-icon://activity-2", "sq": 4, "title": "samsmm", "s_flavor_variant": "5-shared-1", "fo": "shared" }, "Sams": { "group_id": "Sams", "icon": "sap-icon://account", "sq": 1, "title": "Hello", "s_flavor_variant": "5-shared-1", "fo": "shared" }, "wrgfd": { "group_id": "wrgfd", "icon": "sap-icon://accidental-leave", "sq": 2, "title": "gdsfg", "s_flavor_variant": "5-shared-1", "fo": "shared" } };
    exports.default = mm_setting_group;
});
