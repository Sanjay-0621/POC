declare const m_propertytype: {
    $env_user_profile_name: {
        elementid: string;
        length: number;
        r_domain: string;
        short_label: string;
        s_flavor_variant: string;
    };
    app: {
        elementid: string;
        length: number;
        r_domain: string;
        s_flavor_variant: string;
    };
    app_version: {
        elementid: string;
        length: number;
        r_domain: string;
        s_flavor_variant: string;
    };
    bp_type: {
        elementid: string;
        length: number;
        r_domain: string;
        s_flavor_variant: string;
    };
    emp_id: {
        elementid: string;
        length: number;
        r_domain: string;
        s_flavor_variant: string;
    };
    has_own_tenant: {
        elementid: string;
        r_domain: string;
        s_flavor_variant: string;
    };
    login_id: {
        elementid: string;
        length: number;
        r_domain: string;
        s_flavor_variant: string;
    };
    me: {
        elementid: string;
        length: number;
        r_domain: string;
        s_flavor_variant: string;
    };
    now: {
        elementid: string;
        length: number;
        r_domain: string;
        s_flavor_variant: string;
    };
    owning_bp: {
        elementid: string;
        length: number;
        r_domain: string;
        s_flavor_variant: string;
    };
    role: {
        elementid: string;
        length: number;
        r_domain: string;
        s_flavor_variant: string;
    };
    role_id: {
        elementid: string;
        length: number;
        r_domain: string;
        s_flavor_variant: string;
    };
    s_action: {
        elementid: string;
        length: number;
        r_domain: string;
        s_flavor_variant: string;
    };
    today: {
        elementid: string;
        length: number;
        r_domain: string;
        s_flavor_variant: string;
    };
};
export default m_propertytype;
