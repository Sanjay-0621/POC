declare const configs: {
    vh_config: any[];
    configs: any[];
};
export default configs;
