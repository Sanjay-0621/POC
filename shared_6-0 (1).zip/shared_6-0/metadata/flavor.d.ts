declare const flavor: {
    flavor: string;
    version: number;
    account: number;
    fvid: string;
    bol_version: string;
    ui_version: string;
    network_mode: string;
    usedByFlavors: any[];
    usedFlavors: {
        fvid: string;
        parent_fvid: any;
    };
    parentFlavor: any;
}[];
export default flavor;
