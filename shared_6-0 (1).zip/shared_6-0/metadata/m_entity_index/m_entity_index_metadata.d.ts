declare const m_entity_index: {};
export default m_entity_index;
