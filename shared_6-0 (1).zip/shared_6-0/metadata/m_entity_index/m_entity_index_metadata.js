define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var m_entity_index = {};
    exports.default = m_entity_index;
});
