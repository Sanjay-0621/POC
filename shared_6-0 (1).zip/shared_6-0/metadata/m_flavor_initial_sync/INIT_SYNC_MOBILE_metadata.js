define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var INIT_SYNC_MOBILE = { "flavor_id": "shared", "p_initial_sync_set": "INIT_SYNC_MOBILE", "s_flavor_variant": "5-shared-1", "saved_srch": [{ "deferred_execution": 0, "flavor_id": "shared", "p_saved_search_id": "DOLLAR_VALUES_BP", "s_flavor_variant": "5-shared-1" }, { "deferred_execution": 0, "flavor_id": "shared", "p_saved_search_id": "DOLLAR_VALUES_USER", "s_flavor_variant": "5-shared-1" }] };
    exports.default = INIT_SYNC_MOBILE;
});
