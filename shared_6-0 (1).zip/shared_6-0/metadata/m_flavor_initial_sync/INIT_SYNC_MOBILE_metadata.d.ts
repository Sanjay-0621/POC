declare const INIT_SYNC_MOBILE: {
    flavor_id: string;
    p_initial_sync_set: string;
    s_flavor_variant: string;
    saved_srch: {
        deferred_execution: number;
        flavor_id: string;
        p_saved_search_id: string;
        s_flavor_variant: string;
    }[];
};
export default INIT_SYNC_MOBILE;
