declare const env_user: {
    boid: string;
    botype: string;
    description: string;
    entityname: string;
    has_created_fields: number;
    has_modified_fields: number;
    has_object_type: number;
    has_status: number;
    has_tenantid: number;
    isrootnode: number;
    is_metadata: number;
    metadata_type: number;
    owning_flavor: string;
    s_flavor_variant: string;
    fo: string;
    properties: ({
        entityname: string;
        entitypropertyid: string;
        has_id_series: number;
        ismandatory: number;
        isprimarykey: number;
        istransientfield: number;
        property_type: string;
        s_flavor_variant: string;
    } | {
        entityname: string;
        entitypropertyid: string;
        property_type: string;
        s_flavor_variant: string;
        has_id_series?: undefined;
        ismandatory?: undefined;
        isprimarykey?: undefined;
        istransientfield?: undefined;
    })[];
};
export default env_user;
