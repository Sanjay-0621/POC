declare const mobileSavedInitialQueries: {
    p_saved_id: string;
    queryid: string;
    queryjson: string;
    s_flavor_variant: string;
}[];
export default mobileSavedInitialQueries;
