define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var mm_setting = { "shivam": { "data_type": "string", "desc": "Testing", "group_id": "Sams", "icon": "sap-icon://accounting-document-verification", "modifiable_in": "B", "setting_id": "shivam", "sq": 8, "title": "shivam1", "ui_type": "input", "value": "1", "s_flavor_variant": "5-shared-1", "fo": "shared" } };
    exports.default = mm_setting;
});
