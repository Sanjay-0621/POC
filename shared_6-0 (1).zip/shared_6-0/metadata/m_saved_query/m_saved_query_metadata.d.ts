declare const m_saved_query: {
    DOLLAR_VALUES_BP: {
        p_saved_id: string;
        queryid: string;
        queryjson: string;
        s_flavor_variant: string;
    };
    DOLLAR_VALUES_ROLE: {
        p_saved_id: string;
        queryid: string;
        queryjson: string;
        s_flavor_variant: string;
    };
    DOLLAR_VALUES_USER: {
        p_saved_id: string;
        queryid: string;
        queryjson: string;
        s_flavor_variant: string;
    };
};
export default m_saved_query;
