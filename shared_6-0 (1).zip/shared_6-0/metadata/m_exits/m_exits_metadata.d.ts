declare const m_exits: {};
export default m_exits;
