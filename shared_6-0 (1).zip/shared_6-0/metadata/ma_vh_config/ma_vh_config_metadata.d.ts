declare const ma_vh_config: {};
export default ma_vh_config;
