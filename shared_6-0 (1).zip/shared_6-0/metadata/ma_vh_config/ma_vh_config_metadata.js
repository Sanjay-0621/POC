define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var ma_vh_config = {};
    exports.default = ma_vh_config;
});
