declare const m_idseries_defination: {};
export default m_idseries_defination;
