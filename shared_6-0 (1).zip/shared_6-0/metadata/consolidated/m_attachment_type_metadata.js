define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var m_attachment_type = {};
    exports.default = m_attachment_type;
});
