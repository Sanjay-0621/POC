declare const mwf_group: {};
export default mwf_group;
