declare const allNames: {
    m_propertytype: {
        $env_user_profile_name: {};
        app: {};
        app_version: {};
        bp_type: {};
        emp_id: {};
        has_own_tenant: {};
        login_id: {};
        me: {};
        now: {};
        owning_bp: {};
        role: {};
        role_id: {};
        s_action: {};
        today: {};
    };
    ma_vh_config: {};
    mm_setting: {
        sb_attchment_sync: {};
        sb_lang: {};
        sb_vh_format: {};
        sb_number_format: {};
        sb_display_scaling: {};
        sb_date_format: {};
        sb_dark_mode: {};
    };
    mm_setting_group: {
        other: {};
        general: {};
        display: {};
        basic: {};
    };
    mm_setting_value: {};
    mu_faq: {};
    mu_homepage: {};
    mu_menu_hdr: {};
    mu_screen: {};
    mwf_group: {};
    mwf_header: {};
    m_attachment_type: {};
    m_entities: {
        env_bp: {};
        env_role: {};
        env_system: {};
        env_user: {};
    };
    m_entity_index: {};
    m_exits: {};
    m_flavor_initial_sync: {
        INIT_SYNC_MOBILE: {};
    };
    m_idseries_defination: {};
    m_lang: {};
    m_notification: {};
    m_propertytype_lang: {};
    m_queries: {};
    m_saved_query: {
        DOLLAR_VALUES_BP: {};
        DOLLAR_VALUES_ROLE: {};
        DOLLAR_VALUES_USER: {};
    };
    m_value_help_def: {};
};
export default allNames;
