declare const mm_setting_value: {};
export default mm_setting_value;
