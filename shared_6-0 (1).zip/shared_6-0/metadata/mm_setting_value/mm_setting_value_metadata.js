define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var mm_setting_value = {};
    exports.default = mm_setting_value;
});
