import * as BaseController from 'kloTouch/controller/BaseController'
import { ClassMap } from 'kloBo/_init/ClassMap';
import { KloQuery } from 'kloBo/KloQuery';
import { NetworkModes } from 'kloBo/kloCommon/Network/NetworkModes';
import { m_inbox } from 'core_fw/entity';
import { AUTHORIZATION_TYPE, KloAjax } from 'kloBo/kloCommon/Ajax/KloAjaxHandler';
declare let KloUI5:any;
@KloUI5("shared.controller.notification_inbox")
export default class notification_inbox extends BaseController.BaseController{

    private _busyIndicator = new sap.m.BusyDialog({});

	public async onAfterAllRendered() {
        try
        {
            this._busyIndicator.open();
            let queryInstance1 : KloQuery<m_inbox> = await ClassMap.getQueryP("core_fw","m_inbox",this.transaction);
            queryInstance1.setLoadAll(true);
            queryInstance1.setNetWorkMode(NetworkModes.ONLINE); // online only for testing
            queryInstance1["status_NE"] = "OLD"; 
            queryInstance1["type"] = "REQUEST"; 
            let resultSet1 = await queryInstance1.executeP();
            this.tm.$M.setProperty("/list_request",resultSet1);

            let queryInstance2 : KloQuery<m_inbox> = await ClassMap.getQueryP("core_fw","m_inbox",this.transaction);
            queryInstance2.setLoadAll(true);
            queryInstance2.setNetWorkMode(NetworkModes.ONLINE); // online only for testing
            queryInstance2["status_NE"] = "OLD"; 
            queryInstance2["type"] = "REMINDER"; 
            let resultSet2 = await queryInstance2.executeP();
            this.tm.$M.setProperty("/list_reminder",resultSet2);

            let queryInstance3 : KloQuery<m_inbox> = await ClassMap.getQueryP("core_fw","m_inbox",this.transaction);
            queryInstance3.setLoadAll(true);
            queryInstance3.setNetWorkMode(NetworkModes.ONLINE); // online only for testing
            queryInstance3["status_NE"] = "OLD"; 
            queryInstance3["type"] = "ESCALATION"; 
            let resultSet3 = await queryInstance3.executeP();
            this.tm.$M.setProperty("/list_escalation",resultSet3);

            let queryInstance4 : KloQuery<m_inbox> = await ClassMap.getQueryP("core_fw","m_inbox",this.transaction);
            queryInstance4.setLoadAll(true);
            queryInstance4.setNetWorkMode(NetworkModes.ONLINE); // online only for testing
            queryInstance4["status_NE"] = "OLD"; 
            queryInstance4["type"] = "INFO"; 
            let resultSet4 = await queryInstance4.executeP();
            this.tm.$M.setProperty("/list_info",resultSet4);
            this._busyIndicator.close();
        }
        catch(e)
        {
            this._busyIndicator.close();
            sap.m.MessageToast.show("Error : "+e);
        }
	}

    public async onPressApprove(oEvent : sap.ui.base.Event)
    {
        try
        {
            this._busyIndicator.open();
            let action : string = (<sap.m.Button>oEvent.getSource()).getText();
            let sPath : string = (<sap.m.Button>oEvent.getSource()).getBindingContext("t_notification_inbox").getPath();
            let data : string = this.tm.$M.getProperty(sPath + "/data");
            if(data?.length > 0)
            {
                let JSONData : object = JSON.parse(data);
                let prepareData : object = {
                    "actionid" : JSONData?.["actionid"],
                    // "wfid" : JSONData?.["wfid"],
                    "task_instanceid" : JSONData?.["task_instanceid"],
                    "wf_instanceid" : JSONData?.["wf_instanceid"]
                };
                let ajax : KloAjax = KloAjax.getInstance();
                ajax.perFormApiAction("wfAction",prepareData,JSONData?.["fvid"],JSONData?.["version"]).then(function (e){
                    this._busyIndicator.close();
                    sap.m.MessageToast.show("Request Approved.")
                    this.setStatusInbox(e,this.tm.$M.getProperty(sPath + "/inbox_id"));

                }.bind(this)).catch(function (e) {

                    console.log(e);
                    this._busyIndicator.close();
                    sap.m.MessageToast.show("Action Failed : Error :" + e);
                }.bind(this));
            }
        }
        catch(e)
        {
            console.log(e);
            this._busyIndicator.close();
            sap.m.MessageToast.show("Error :" + e);
        }
    }

    public async onPressReject(oEvent : sap.ui.base.Event)
    {
        try {
            this._busyIndicator.open();
            let action : string = (<sap.m.Button>oEvent.getSource()).getText();
            let sPath : string = (<sap.m.Button>oEvent.getSource()).getBindingContext("t_notification_inbox").getPath();
            let data : string = this.tm.$M.getProperty(sPath + "/data");
            if(data?.length >0)
            {
                let JSONData : object = JSON.parse(data);
                let prepareData : object = {
                    "actionid" : JSONData?.["actionid"],
                    // "wfid" : JSONData?.["wfid"],
                    "task_instanceid" : JSONData?.["task_instanceid"],
                    "wf_instanceid" : JSONData?.["wf_instanceid"]
                };
                let ajax : KloAjax = KloAjax.getInstance();
                ajax.perFormApiAction("wfAction",prepareData,JSONData?.["fvid"],JSONData?.["version"]).then(function (e){
                    this._busyIndicator.close();
                    sap.m.MessageToast.show("Request Rejected.")
                    this.setStatusInbox(e,this.tm.$M.getProperty(sPath + "/inbox_id"));

                }.bind(this)).catch(function (e) {
                    
                    console.log(e);
                    this._busyIndicator.close();
                    sap.m.MessageToast.show("Action Failed : Error :" + e);
                }.bind(this));
            }
        }
        catch(e)
        {
            console.log(e);
            this._busyIndicator.close();
            sap.m.MessageToast.show("Error :" + e);
        }
    }

    public async setStatusInbox(e : any, inbox_id : string)
    {
        try
        {
            this._busyIndicator.open();
            let requestData : m_inbox[]  = this.tm.$M.getProperty("/list_request");
            let data : m_inbox =  requestData.find((data : m_inbox) => { return data.inbox_id == inbox_id});
            if(data)
                data.status = "OLD";
            await this.transaction.commitP();
            this._busyIndicator.close();
            this.onAfterAllRendered();
        }
        catch(e)
        {
            this._busyIndicator.close();
            console.log(e);
            sap.m.MessageToast.show("Error :" + e);
        }

    }

    public async onPressSearch(oEvent : sap.ui.base.Event , params : { type : string})
    {
        if(params?.type == "REQUEST")
        {
            let searchString : string = this.tm.$M.getProperty("/searchTextRequest");
            let oBinding = <sap.ui.model.odata.v4.ODataListBinding>sap.ui.getCore().byId("notification_inbox_ps_list").getBinding("items");
            let aFilters : sap.ui.model.Filter[] = [];
            let oFilter : sap.ui.model.Filter = new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, searchString);
            aFilters.push(oFilter);
            oBinding.filter(new sap.ui.model.Filter(aFilters),sap.ui.model.FilterType.Application);
        }
        else if(params?.type == "INFO")
        {
            let searchString : string = this.tm.$M.getProperty("/searchTextInfo");
            let oBinding = <sap.ui.model.odata.v4.ODataListBinding>sap.ui.getCore().byId("notification_inbox_ps_list_info").getBinding("items");
            let aFilters : sap.ui.model.Filter[] = [];
            let oFilter : sap.ui.model.Filter = new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, searchString);
            aFilters.push(oFilter);
            oBinding.filter(new sap.ui.model.Filter(aFilters),sap.ui.model.FilterType.Application);

        }
        else if(params?.type == "REMINDER")
        {
            let searchString : string = this.tm.$M.getProperty("/searchTextReminder");
            let oBinding = <sap.ui.model.odata.v4.ODataListBinding>sap.ui.getCore().byId("notification_inbox_ps_list_reminder").getBinding("items");
            let aFilters : sap.ui.model.Filter[] = [];
            let oFilter : sap.ui.model.Filter = new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, searchString);
            aFilters.push(oFilter);
            oBinding.filter(new sap.ui.model.Filter(aFilters),sap.ui.model.FilterType.Application);
        }
        else if(params?.type == "ESCALATION")
        {
            let searchString : string = this.tm.$M.getProperty("/searchTextEscalation");
            let oBinding = <sap.ui.model.odata.v4.ODataListBinding>sap.ui.getCore().byId("notification_inbox_ps_list_escalation").getBinding("items");
            let aFilters : sap.ui.model.Filter[] = [];
            let oFilter : sap.ui.model.Filter = new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, searchString);
            aFilters.push(oFilter);
            oBinding.filter(new sap.ui.model.Filter(aFilters),sap.ui.model.FilterType.Application);
        }
    }
	
}