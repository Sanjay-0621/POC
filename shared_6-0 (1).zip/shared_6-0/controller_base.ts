// controller_base.ts 
