var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
define(["require", "exports", "kloBo/meta/MetadataProxyBase"], function (require, exports, MetadataProxyBase_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.env_role = void 0;
    var env_role = /** @class */ (function (_super) {
        __extends(env_role, _super);
        function env_role() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** ****** System Fields ****** */
        /** ****** relations ****** */
        env_role.prototype.getEntityUniqueKey = function (jsonData) {
            var _a, _b;
            if ((_a = this === null || this === void 0 ? void 0 : this._mystub) === null || _a === void 0 ? void 0 : _a._keyForNewlyCreatedEntity)
                return this._mystub._keyForNewlyCreatedEntity;
            var d = jsonData || ((_b = this._mystub) === null || _b === void 0 ? void 0 : _b._d) || this._dP;
            return d ? 'env_role' + '@@' + d["fvid"] + '@@' + d["is_raw"] + '@@' + d["role_id"] : null;
        };
        env_role.prototype.getEntityUniqueKeyFields = function () { return ['fvid', 'is_raw', 'role_id']; };
        __decorate([
            entProps("string", false, true)
        ], env_role.prototype, "role_id", void 0);
        __decorate([
            entProps("string", false, false)
        ], env_role.prototype, "s_action", void 0);
        return env_role;
    }(MetadataProxyBase_1.MetadataProxyBase));
    exports.env_role = env_role;
});
