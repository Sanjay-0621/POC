import { KloEntity } from "kloBo/KloEntity";

export class env_bp extends KloEntity{

    public get bp_type():string {return this.g("bp_type","string");}
    public set bp_type(new_value:string) {this.s("bp_type",new_value,"string",false,false)}
    public get has_own_tenant():Boolean {return this.g("has_own_tenant","Boolean");}
    public set has_own_tenant(new_value:Boolean) {this.s("has_own_tenant",new_value,"Boolean",false,false)}
    public get me():string {return this.g("me","string");}
    public set me(new_value:string) {this.s("me",new_value,"string",false,true)}
    public get s_action():string {return this.g("s_action","string");}
    public set s_action(new_value:string) {this.s("s_action",new_value,"string",false,false)}
/** ****** System Fields ****** */
/** ****** relations ****** */


    public getEntityUniqueKey(jsonData?:any):string {
        if(this?._mystub?._keyForNewlyCreatedEntity)
            return this._mystub._keyForNewlyCreatedEntity;            
        let d:any =  jsonData || this._mystub?._d || this._dP;
        return d? 'env_bp'+'@@'+d["me"] : null;
    }
    public getEntityUniqueKeyFields():Array<string>{return ['me'];}
}