import { MetadataProxyBase } from "kloBo/meta/MetadataProxyBase";
export declare class env_role extends MetadataProxyBase {
    role_id: string;
    s_action: string;
    getEntityUniqueKey(jsonData?: any): string;
    getEntityUniqueKeyFields(): Array<string>;
}
