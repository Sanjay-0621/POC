import { MetadataProxyBase } from "kloBo/meta/MetadataProxyBase";

export class env_role extends MetadataProxyBase{

    public get role_id():string {return this.g("role_id","string");}
    public set role_id(new_value:string) {this.s("role_id",new_value,"string",false,true)}
    public get s_action():string {return this.g("s_action","string");}
    public set s_action(new_value:string) {this.s("s_action",new_value,"string",false,false)}
/** ****** System Fields ****** */
/** ****** relations ****** */

    public get descr_key():string{return '';}
            

    public getEntityUniqueKey(jsonData?:any):string {
        if(this?._mystub?._keyForNewlyCreatedEntity)
            return this._mystub._keyForNewlyCreatedEntity;            
        let d:any =  jsonData || this._mystub?._d || this._dP;
        return d? 'env_role'+'@@'+d["fvid"]+'@@'+d["is_raw"]+'@@'+d["role_id"] : null;
    }
    public getEntityUniqueKeyFields():Array<string>{return ['fvid','is_raw','role_id'];}
}