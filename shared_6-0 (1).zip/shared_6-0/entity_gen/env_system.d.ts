import { KloEntity } from "kloBo/KloEntity";
export declare class env_system extends KloEntity {
    app: string;
    app_version: string;
    now: Date;
    s_action: string;
    today: Date;
    getEntityUniqueKey(jsonData?: any): string;
    getEntityUniqueKeyFields(): Array<string>;
}
