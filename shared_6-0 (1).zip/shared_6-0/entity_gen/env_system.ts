import { KloEntity } from "kloBo/KloEntity";

export class env_system extends KloEntity{

    public get app():string {return this.g("app","string");}
    public set app(new_value:string) {this.s("app",new_value,"string",false,false)}
    public get app_version():string {return this.g("app_version","string");}
    public set app_version(new_value:string) {this.s("app_version",new_value,"string",false,false)}
    public get now():Date {return this.g("now","Date");}
    public set now(new_value:Date) {this.s("now",new_value,"Date",false,false)}
    public get s_action():string {return this.g("s_action","string");}
    public set s_action(new_value:string) {this.s("s_action",new_value,"string",false,false)}
    public get today():Date {return this.g("today","Date");}
    public set today(new_value:Date) {this.s("today",new_value,"Date",false,false)}
/** ****** System Fields ****** */
/** ****** relations ****** */


    public getEntityUniqueKey(jsonData?:any):string {
        if(this?._mystub?._keyForNewlyCreatedEntity)
            return this._mystub._keyForNewlyCreatedEntity;            
        let d:any =  jsonData || this._mystub?._d || this._dP;
        return d? 'env_system' : null;
    }
    public getEntityUniqueKeyFields():Array<string>{return [''];}
}