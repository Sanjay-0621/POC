import { KloEntity } from "kloBo/KloEntity";

export class env_user extends KloEntity{

    public get emp_id():string {return this.g("emp_id","string");}
    public set emp_id(new_value:string) {this.s("emp_id",new_value,"string",false,false)}
    public get login_id():string {return this.g("login_id","string");}
    public set login_id(new_value:string) {this.s("login_id",new_value,"string",false,true)}
    public get owning_bp():string {return this.g("owning_bp","string");}
    public set owning_bp(new_value:string) {this.s("owning_bp",new_value,"string",false,false)}
    public get profile_name():string {return this.g("profile_name","string");}
    public set profile_name(new_value:string) {this.s("profile_name",new_value,"string",false,false)}
    public get role():string {return this.g("role","string");}
    public set role(new_value:string) {this.s("role",new_value,"string",false,false)}
    public get s_action():string {return this.g("s_action","string");}
    public set s_action(new_value:string) {this.s("s_action",new_value,"string",false,false)}
/** ****** System Fields ****** */
/** ****** relations ****** */


    public getEntityUniqueKey(jsonData?:any):string {
        if(this?._mystub?._keyForNewlyCreatedEntity)
            return this._mystub._keyForNewlyCreatedEntity;            
        let d:any =  jsonData || this._mystub?._d || this._dP;
        return d? 'env_user'+'@@'+d["login_id"] : null;
    }
    public getEntityUniqueKeyFields():Array<string>{return ['login_id'];}
}