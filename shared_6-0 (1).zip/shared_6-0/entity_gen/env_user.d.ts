import { KloEntity } from "kloBo/KloEntity";
export declare class env_user extends KloEntity {
    emp_id: string;
    login_id: string;
    owning_bp: string;
    profile_name: string;
    role: string;
    s_action: string;
    getEntityUniqueKey(jsonData?: any): string;
    getEntityUniqueKeyFields(): Array<string>;
}
