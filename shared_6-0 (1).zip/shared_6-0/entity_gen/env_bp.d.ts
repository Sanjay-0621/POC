import { KloEntity } from "kloBo/KloEntity";
export declare class env_bp extends KloEntity {
    bp_type: string;
    has_own_tenant: Boolean;
    me: string;
    s_action: string;
    getEntityUniqueKey(jsonData?: any): string;
    getEntityUniqueKeyFields(): Array<string>;
}
